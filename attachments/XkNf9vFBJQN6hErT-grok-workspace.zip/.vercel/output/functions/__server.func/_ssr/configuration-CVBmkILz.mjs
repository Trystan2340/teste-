import { t as Configure } from "./gate-Be8AxGo5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/configuration-CVBmkILz.js
var SplitComponent = Configure;
//#endregion
export { SplitComponent as component };
