import { o as Terms } from "./public-DNah83pO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/conditions-Di88ifbw.js
var SplitComponent = Terms;
//#endregion
export { SplitComponent as component };
