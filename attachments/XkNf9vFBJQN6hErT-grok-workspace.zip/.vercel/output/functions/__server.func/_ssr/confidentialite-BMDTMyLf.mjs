import { t as Privacy } from "./public-DNah83pO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/confidentialite-BMDTMyLf.js
var SplitComponent = Privacy;
//#endregion
export { SplitComponent as component };
