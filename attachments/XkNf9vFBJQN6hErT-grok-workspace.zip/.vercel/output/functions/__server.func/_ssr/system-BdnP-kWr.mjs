import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PageHead, c as Toggle, d as money, n as Button } from "./ui-Bc5yfkUn.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SESSIONS, t as HELP, u as useFreev } from "./shell-C0lq602A.mjs";
import { n as spentByCategory, t as flows } from "./calc-CfYY_CoH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/system-BdnP-kWr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Row({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 border-b border-rule py-5 md:grid-cols-12 md:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: label
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: hint
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "md:col-span-7",
			children
		})]
	});
}
function Settings() {
	const theme = useFreev((s) => s.theme);
	const setTheme = useFreev((s) => s.setTheme);
	const settings = useFreev((s) => s.settings);
	const patch = useFreev((s) => s.patchSettings);
	const open = useFreev((s) => s.open);
	const profile = useFreev((s) => s.profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Réglages",
			title: "Paramètres",
			lede: "Apparence, langue, alertes, et la porte vers l’activité professionnelle."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Apparence",
			hint: "Encre sombre, papier clair, ou le réglage de l’appareil.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					["ink", "Sombre"],
					["paper", "Clair"],
					["system", "Système"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTheme(id),
					className: theme === id ? "h-10 border border-copper px-3 text-xs uppercase tracking-widest text-copper" : "h-10 border border-rule px-3 text-xs uppercase tracking-widest text-mist",
					children: label
				}, id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Devise",
			hint: "Le livre est tenu en euros.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "EUR"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Langue",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Français"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Début de semaine",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Lundi"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Notifications e-mail",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: settings.notifEmail,
				onChange: (v) => patch({ notifEmail: v }),
				label: "E-mail"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Notifications push",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: settings.notifPush,
				onChange: (v) => patch({ notifPush: v }),
				label: "Push"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Récapitulatif hebdomadaire",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: settings.notifWeekly,
				onChange: (v) => patch({ notifWeekly: v }),
				label: "Hebdo"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Conseils",
			hint: "Suggestions sur l’écran Smart.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: settings.advice,
				onChange: (v) => patch({ advice: v }),
				label: "Conseils"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Comptes",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open({ name: "accounts" }),
						children: "Gérer les comptes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open({ name: "opening" }),
						children: "Solde de départ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open({ name: "transfer" }),
						children: "Entre comptes"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Professionnel",
			hint: profile.name,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/parametres-pro",
				className: "text-xs uppercase tracking-widest text-copper",
				children: "Paramètres professionnels"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Données",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						const data = useFreev.getState();
						const blob = new Blob([JSON.stringify({
							txs: data.txs,
							accounts: data.accounts,
							goals: data.goals
						}, null, 2)], { type: "application/json" });
						const url = URL.createObjectURL(blob);
						const a = document.createElement("a");
						a.href = url;
						a.download = "freev-export.json";
						a.click();
						URL.revokeObjectURL(url);
						toast("Export téléchargé");
					},
					children: "Exporter"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => open({ name: "wipe" }),
					children: "Supprimer"
				})]
			})
		})
	] });
}
function ProSettings() {
	const pro = useFreev((s) => s.pro);
	const patch = useFreev((s) => s.patchPro);
	const open = useFreev((s) => s.open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Studio",
			title: "Paramètres professionnels",
			lede: "Identité, factures, relances."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Nom commercial",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.tradeName,
				onChange: (e) => patch({ tradeName: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "SIRET",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.siret,
				onChange: (e) => patch({ siret: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "TVA",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.vat,
				onChange: (e) => patch({ vat: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Adresse",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.address,
				onChange: (e) => patch({ address: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Préfixe des factures",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.prefix,
				onChange: (e) => patch({ prefix: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Délai de paiement (jours)",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.delay,
				onChange: (e) => patch({ delay: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Mention",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: pro.mention,
				onChange: (e) => patch({ mention: e.target.value }),
				className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Relances automatiques",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: pro.remind,
				onChange: (v) => patch({ remind: v }),
				label: "Relances"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Relance si retard",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				on: pro.remindLate,
				onChange: (v) => patch({ remindLate: v }),
				label: "Retard"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: "Comptes encaissement",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => open({ name: "accounts" }),
				children: "Gérer les comptes"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => toast("Paramètres professionnels enregistrés"),
				children: "Enregistrer"
			})
		})
	] });
}
var STEPS = [
	"Aperçu",
	"Anomalies",
	"Budget",
	"Rapport"
];
function MonthCheck() {
	const [step, setStep] = (0, import_react.useState)(0);
	const txs = useFreev((s) => s.txs);
	const budgets = useFreev((s) => s.budgets);
	const flow = flows(txs, "both");
	const split = spentByCategory(txs, "both");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Centre",
				title: "Contrôle mensuel",
				lede: "Quatre temps pour fermer novembre sans rien laisser de côté."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-wrap gap-2",
				children: STEPS.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setStep(i),
					className: i === step ? "h-10 border border-copper px-3 text-xs uppercase tracking-widest" : "h-10 border border-rule px-3 text-xs uppercase tracking-widest text-mist",
					children: [
						i + 1,
						". ",
						label
					]
				}) }, label))
			}),
			step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border border-rule p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs uppercase tracking-widest text-mist",
							children: "Entrées"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-3xl",
							children: money(flow.inn)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border border-rule p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs uppercase tracking-widest text-mist",
							children: "Sorties"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-3xl",
							children: money(flow.out)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border border-rule p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs uppercase tracking-widest text-mist",
							children: "Net"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-3xl",
							children: money(flow.rest)
						})]
					})
				]
			}) : null,
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "divide-y divide-rule border-y border-rule text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-3",
						children: "EDF est 18 % au-dessus de la moyenne des six derniers mois."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-3",
						children: "Deux abonnements se renouvellent encore cette semaine."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-3",
						children: "La facture Studio Lina est toujours en attente."
					})
				]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-rule border-y border-rule",
				children: split.map((c) => {
					const cap = budgets[c.name];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [money(c.value), cap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-mist",
								children: [" / ", money(cap)]
							}) : null]
						})]
					}, c.name);
				})
			}) : null,
			step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "max-w-xl text-sm text-mist",
				children: [
					"Novembre se ferme avec un net de ",
					money(flow.rest),
					". Le rapport reprend les mêmes chiffres."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/rapport",
				className: "mt-4 inline-block text-xs uppercase tracking-widest text-copper",
				children: "Ouvrir le rapport"
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setStep((s) => Math.max(0, s - 1)),
					disabled: step === 0,
					children: "Retour"
				}), step < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => setStep((s) => s + 1),
					children: "Continuer"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => toast("Contrôle de novembre terminé"),
					children: "Terminer"
				})]
			})
		]
	});
}
function Rules() {
	const rules = useFreev((s) => s.rules);
	const toggle = useFreev((s) => s.toggleRule);
	const add = useFreev((s) => s.addRule);
	const [name, setName] = (0, import_react.useState)("");
	const [when, setWhen] = (0, import_react.useState)("");
	const [action, setAction] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Centre",
				title: "Règles",
				lede: "Si quelque chose se produit, FREEV fait le geste que vous avez écrit."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-rule border-y border-rule",
				children: rules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: r.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-mist",
						children: [
							"Si ",
							r.when,
							" → ",
							r.action
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: r.on,
						onChange: () => toggle(r.id),
						label: r.name
					})]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 md:grid-cols-4",
				onSubmit: (e) => {
					e.preventDefault();
					if (!name.trim()) return;
					add({
						name: name.trim(),
						when: when || "condition",
						action: action || "Notifier",
						on: true
					});
					setName("");
					setWhen("");
					setAction("");
					toast("Règle ajoutée");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Nom",
						className: "border-b border-rule bg-transparent py-2 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: when,
						onChange: (e) => setWhen(e.target.value),
						placeholder: "Condition",
						className: "border-b border-rule bg-transparent py-2 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: action,
						onChange: (e) => setAction(e.target.value),
						placeholder: "Action",
						className: "border-b border-rule bg-transparent py-2 text-sm outline-none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						children: "Nouvelle règle"
					})
				]
			})
		]
	});
}
function Subscriptions() {
	const subs = useFreev((s) => s.subs);
	const setStatus = useFreev((s) => s.setSubStatus);
	const open = useFreev((s) => s.open);
	const monthly = subs.filter((s) => s.status === "actif" || s.status === "essai").reduce((s, x) => s + x.price, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Centre",
			title: "Abonnements",
			lede: `${money(monthly)} partent encore chaque mois.`,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => open({ name: "trial" }),
				children: "Nouvel essai"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-rule border-y border-rule",
			children: subs.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-3 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: s.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: [
						s.status,
						" · ",
						s.renews,
						s.trialEnd ? ` · fin d’essai ${s.trialEnd}` : ""
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: money(s.price)
					}), s.status !== "résilié" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => setStatus(s.id, s.status === "pause" ? "actif" : "pause"),
						children: s.status === "pause" ? "Reprendre" : "Pause"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => setStatus(s.id, "résilié"),
						children: "Résilier"
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: "résilié"
					})]
				})]
			}, s.id))
		})]
	});
}
function Wealth() {
	const accounts = useFreev((s) => s.accounts);
	const debts = useFreev((s) => s.debts);
	const goals = useFreev((s) => s.goals);
	const liquid = accounts.reduce((s, a) => s + a.balance, 0);
	const debt = debts.reduce((s, d) => s + d.remaining, 0);
	const goalsSum = goals.reduce((s, g) => s + g.current, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Centre",
				title: "Patrimoine",
				lede: "Liquidités, objectifs, dettes. Le net est la seule ligne qui compte."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-5xl tabular-nums",
				children: money(liquid - debt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Patrimoine net · liquidités moins dettes. Les objectifs sont déjà dans les livrets."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid gap-4 border-y border-rule sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Liquidités"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-serif text-3xl",
							children: money(liquid)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Dans les objectifs"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-serif text-3xl",
							children: money(goalsSum)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Dettes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-serif text-3xl",
							children: money(debt)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-4 text-xs uppercase tracking-widest",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/epargne",
						className: "text-copper",
						children: "Épargne"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dettes",
						className: "text-copper",
						children: "Dettes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-copper",
						children: "Comptes"
					})
				]
			})
		]
	});
}
function Security() {
	const twoFa = useFreev((s) => s.twoFa);
	const setTwoFa = useFreev((s) => s.setTwoFa);
	const closed = useFreev((s) => s.closedSessions);
	const close = useFreev((s) => s.closeSession);
	const [password, setPassword] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Centre",
				title: "Sécurité",
				lede: "Mot de passe, seconde étape, sessions ouvertes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "max-w-md space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (password.length < 8) {
						toast("Huit caractères minimum");
						return;
					}
					setPassword("");
					toast("Mot de passe mis à jour");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: "Nouveau mot de passe"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "password",
						value: password,
						onChange: (e) => setPassword(e.target.value),
						className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "primary",
					children: "Changer le mot de passe"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-y border-rule py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Validation en deux étapes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: twoFa ? "Active sur cet appareil." : "Encore inactive."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					on: twoFa,
					onChange: setTwoFa,
					label: "Deux étapes"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-rule",
				children: SESSIONS.filter((s) => !closed.includes(s.id)).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm",
						children: s.device
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: s.when
					})] }), s.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-copper",
						children: "Cet appareil"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => close(s.id),
						children: "Fermer"
					})]
				}, s.id))
			})
		]
	});
}
function Account() {
	const profile = useFreev((s) => s.profile);
	const patch = useFreev((s) => s.patchProfile);
	const [name, setName] = (0, import_react.useState)(profile.name);
	const [email, setEmail] = (0, import_react.useState)(profile.email);
	const [mode, setMode] = (0, import_react.useState)(profile.defaultMode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Compte",
			title: "Mon compte",
			lede: "Le nom qui signe les rapports et l’e-mail des alertes."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "max-w-md space-y-4",
			onSubmit: (e) => {
				e.preventDefault();
				patch({
					name,
					email,
					defaultMode: mode
				});
				toast("Compte enregistré");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: "Nom"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: "E-mail"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: "Mode par défaut"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: mode,
						onChange: (e) => setMode(e.target.value),
						className: "mt-1 w-full border-b border-rule bg-transparent py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "perso",
								children: "Personnel"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pro",
								children: "Pro"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "both",
								children: "Les deux"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "primary",
					children: "Enregistrer"
				})
			]
		})]
	});
}
function Help() {
	const [id, setId] = (0, import_react.useState)(HELP[0].id);
	const current = HELP.find((h) => h.id === id) ?? HELP[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Aide",
			title: "Mode d’emploi",
			lede: "Cinq gestes, pas un manuel."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-8 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "lg:col-span-4",
				children: HELP.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setId(h.id),
					className: h.id === id ? "block w-full border-l-2 border-copper py-3 pl-3 text-left" : "block w-full border-l-2 border-transparent py-3 pl-3 text-left text-mist",
					children: h.title
				}) }, h.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "lg:col-span-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-3xl",
					children: current.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-sm text-mist",
					children: current.body
				})]
			})]
		})]
	});
}
function Scanner() {
	const add = useFreev((s) => s.addTx);
	const [file, setFile] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Capture",
				title: "Scanner un reçu",
				lede: "Déposez une photo. On en tire un libellé et un montant à confirmer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-56 cursor-pointer flex-col items-center justify-center border border-dashed border-rule p-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif text-3xl",
						children: file ? "Reçu lu" : "Déposer un reçu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 text-sm text-mist",
						children: file ?? "JPG ou PNG · la lecture reste sur cet appareil"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						className: "sr-only",
						onChange: (e) => {
							const f = e.target.files?.[0];
							setFile(f ? f.name : null);
							setSaved(false);
						}
					})
				]
			}),
			file ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-rule p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-copper",
						children: "Lecture"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: "Courses · 42,18 € · Alimentation · compte courant"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						variant: "primary",
						disabled: saved,
						onClick: () => {
							add({
								date: "2026-11-19",
								label: "Reçu scanné",
								category: "Alimentation",
								accountId: "courant",
								amount: -42.18,
								scope: "perso",
								kind: "expense",
								recurring: false,
								pending: false
							});
							setSaved(true);
							toast("Reçu ajouté au journal");
						},
						children: saved ? "Ajouté" : "Enregistrer dans le journal"
					})
				]
			}) : null
		]
	});
}
//#endregion
export { Rules as a, Settings as c, ProSettings as i, Subscriptions as l, Help as n, Scanner as o, MonthCheck as r, Security as s, Account as t, Wealth as u };
