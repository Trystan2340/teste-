import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as format, n as parseISO, t as fr } from "../_libs/date-fns.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-Bc5yfkUn.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function money(n, digits) {
	digits ?? Number.isInteger(Math.round(n * 100) / 100);
	const rounded = Math.round(n * 100) / 100;
	const use = Number.isInteger(rounded) ? 0 : 2;
	return new Intl.NumberFormat("fr-FR", {
		style: "currency",
		currency: "EUR",
		minimumFractionDigits: digits ?? use,
		maximumFractionDigits: digits ?? use
	}).format(n);
}
function signed(n) {
	const formatted = money(Math.abs(n));
	if (n > 0) return `+${formatted}`;
	if (n < 0) return `−${formatted}`;
	return formatted;
}
function pct(n) {
	return `${new Intl.NumberFormat("fr-FR", {
		minimumFractionDigits: 1,
		maximumFractionDigits: 1,
		signDisplay: "exceptZero"
	}).format(n)} %`;
}
function dayLabel(iso) {
	return format(parseISO(iso), "d MMM", { locale: fr });
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}
var buttonStyles = cva("inline-flex items-center justify-center gap-2 border text-xs font-medium uppercase tracking-widest transition-colors disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "border-copper bg-copper text-copper-ink hover:border-ink hover:bg-ink hover:text-canvas",
			ghost: "border-rule bg-transparent text-ink hover:border-ink",
			quiet: "border-transparent bg-transparent px-0 text-mist hover:text-ink"
		},
		size: {
			md: "h-11 px-4",
			sm: "h-9 px-3"
		}
	},
	defaultVariants: {
		variant: "ghost",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonStyles({
			variant,
			size
		}), className),
		...props
	});
}
function Field({ label, hint, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("block", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs uppercase tracking-widest text-mist",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "mt-1 w-full border-0 border-b border-rule bg-transparent py-2 text-sm text-ink outline-none placeholder:text-mist focus:border-copper",
				...props
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs text-clay",
				children: hint
			}) : null
		]
	});
}
function Select({ label, children, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("block", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs uppercase tracking-widest text-mist",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			className: "mt-1 w-full border-0 border-b border-rule bg-transparent py-2 text-sm text-ink outline-none focus:border-copper",
			...props,
			children
		})]
	});
}
function Toggle({ on, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		"aria-label": label,
		onClick: () => onChange(!on),
		className: cn("relative h-6 w-11 border", on ? "border-copper bg-copper" : "border-rule bg-transparent"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-4 transition-transform", on ? "translate-x-6 bg-copper-ink" : "translate-x-0.5 bg-mist") })
	});
}
function PageHead({ kicker, title, lede, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-col gap-4 border-b border-rule pb-6 md:flex-row md:items-end md:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-copper",
					children: kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-serif text-4xl leading-none text-ink md:text-5xl",
					children: title
				}),
				lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-sm text-mist",
					children: lede
				}) : null
			]
		}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: actions
		}) : null]
	});
}
function Stat({ label, value, note, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-5 first:pl-0 last:pr-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-mist",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-serif text-3xl tabular-nums text-ink",
				children: value
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 text-sm", tone === "sage" && "text-sage", tone === "clay" && "text-clay", (!tone || tone === "mist") && "text-mist"),
				children: note
			}) : null
		]
	});
}
function Amount({ value, kind }) {
	if (kind === "transfer") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums text-mist",
		children: money(value)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular-nums", value > 0 && "text-sage", value < 0 && "text-clay"),
		children: signed(value)
	});
}
function Empty({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-dashed border-rule px-4 py-10 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-2xl",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-mist",
			children: body
		})]
	});
}
//#endregion
export { PageHead as a, Toggle as c, money as d, pct as f, Field as i, cn as l, Button as n, Select as o, uid as p, Empty as r, Stat as s, Amount as t, dayLabel as u };
