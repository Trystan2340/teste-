import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Shell } from "./shell-C0lq602A.mjs";
import { l as Subscriptions } from "./system-BdnP-kWr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/abonnements-DfZfA6ge.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Subscriptions, {}) });
};
//#endregion
export { SplitComponent as component };
