import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PageHead, d as money, n as Button, r as Empty, t as Amount, u as dayLabel } from "./ui-Bc5yfkUn.mjs";
import { i as SERIES, l as inScope, n as HISTORY, u as useFreev } from "./shell-C0lq602A.mjs";
import { t as FlowChart } from "./charts-DJqplFPt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/money-yrIiR5OG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Transactions() {
	const txs = useFreev((s) => s.txs);
	const accounts = useFreev((s) => s.accounts);
	const mode = useFreev((s) => s.mode);
	const open = useFreev((s) => s.open);
	const [q, setQ] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("toutes");
	const [account, setAccount] = (0, import_react.useState)("tous");
	const [kind, setKind] = (0, import_react.useState)("tous");
	const cats = (0, import_react.useMemo)(() => ["toutes", ...new Set(txs.map((t) => t.category))], [txs]);
	const rows = txs.filter((t) => inScope(t.scope, mode)).filter((t) => cat === "toutes" ? true : t.category === cat).filter((t) => account === "tous" ? true : t.accountId === account).filter((t) => kind === "tous" ? true : t.kind === kind).filter((t) => !q || `${t.label} ${t.category}`.toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.date.localeCompare(a.date));
	const sum = rows.filter((t) => t.kind !== "transfer").reduce((s, t) => s + t.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Opérations",
				title: "Transactions",
				lede: "Le journal filtré selon le périmètre choisi en haut de page.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/scanner",
					className: "inline-flex h-11 items-center border border-rule px-4 text-xs uppercase tracking-widest",
					children: "Scanner"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => open({ name: "tx" }),
					children: "Nouvelle opération"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 border-y border-rule py-4 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Recherche"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: q,
							onChange: (e) => setQ(e.target.value),
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 text-sm outline-none",
							placeholder: "Libellé"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Catégorie"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: cat,
							onChange: (e) => setCat(e.target.value),
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 text-sm",
							children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Compte"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: account,
							onChange: (e) => setAccount(e.target.value),
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "tous",
								children: "tous"
							}), accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.id,
								children: a.name
							}, a.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Type"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: kind,
							onChange: (e) => setKind(e.target.value),
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "tous",
									children: "tous"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "expense",
									children: "dépense"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "income",
									children: "revenu"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "transfer",
									children: "virement"
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mist",
				children: [
					rows.length,
					" ligne",
					rows.length > 1 ? "s" : "",
					" · sous-total ",
					money(sum)
				]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Journal vide",
				body: "Aucune opération ne correspond. Élargissez les filtres ou ajoutez une ligne."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Libellé"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Catégorie"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Compte"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 text-right font-medium",
								children: "Montant"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-rule",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 whitespace-nowrap",
								children: dayLabel(t.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-3",
								children: [t.label, t.pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-xs uppercase tracking-widest text-copper",
									children: "prévu"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-mist",
								children: t.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-mist",
								children: accounts.find((a) => a.id === t.accountId)?.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, {
									value: t.amount,
									kind: t.kind
								})
							})
						]
					}, t.id)) })]
				})
			})
		]
	});
}
function Recurring() {
	const txs = useFreev((s) => s.txs);
	const open = useFreev((s) => s.open);
	const remove = useFreev((s) => s.removeTx);
	const rows = txs.filter((t) => t.recurring);
	const out = rows.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);
	const inn = rows.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Opérations",
				title: "Récurrences",
				lede: "Ce qui revient chaque mois : loyer, énergie, abonnements, prélèvements.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => open({ name: "recurrence" }),
					children: "Nouvelle récurrence"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mist",
				children: [
					"Sorties récurrentes ",
					money(out),
					" · revenus récurrents ",
					money(inn)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-rule border-y border-rule",
				children: rows.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: t.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: [
							t.category,
							" · jour ",
							Number(t.date.slice(8, 10)),
							" · ",
							t.scope === "pro" ? "pro" : "perso"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, {
								value: t.amount,
								kind: t.kind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => open({
									name: "recurrence",
									id: t.id
								}),
								children: "Modifier"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => remove(t.id),
								children: "Retirer"
							})
						]
					})]
				}, t.id))
			})
		]
	});
}
function HistoryPage() {
	const [id, setId] = (0, import_react.useState)(HISTORY[0].id);
	const current = HISTORY.find((h) => h.id === id) ?? HISTORY[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Opérations",
				title: "Historique",
				lede: "Six mois de flux. Novembre ouvre le journal détaillé."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowChart, { data: [...SERIES] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-rule border-y border-rule lg:col-span-5",
					children: HISTORY.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setId(h.id),
						className: "flex w-full items-center justify-between py-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: h.id === id ? "text-ink" : "text-mist",
							children: h.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-sm",
							children: money(h.inn - h.out)
						})]
					}) }, h.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-rule p-5 lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-copper",
							children: current.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: "Entrées"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-serif text-2xl",
									children: money(current.inn)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: "Sorties"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-serif text-2xl",
									children: money(current.out)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: "Net"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-serif text-2xl",
									children: money(current.inn - current.out)
								})] })
							]
						}),
						current.id === "2026-11" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/transactions",
							className: "mt-6 inline-block text-xs uppercase tracking-widest text-copper",
							children: "Ouvrir le journal de novembre"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-mist",
							children: "Le détail ligne à ligne est tenu pour novembre. Les mois précédents restent en agrégat."
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { Recurring as n, Transactions as r, HistoryPage as t };
