import { r as PublicCash } from "./public-DNah83pO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tresorerie-CgMUyZy8.js
var SplitComponent = PublicCash;
//#endregion
export { SplitComponent as component };
