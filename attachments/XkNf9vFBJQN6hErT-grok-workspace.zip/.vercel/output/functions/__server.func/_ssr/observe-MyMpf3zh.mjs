import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PageHead, d as money, f as pct, n as Button, s as Stat, t as Amount, u as dayLabel } from "./ui-Bc5yfkUn.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as TODAY, i as SERIES, l as inScope, n as HISTORY, o as SNAP, r as SCHEDULE, u as useFreev } from "./shell-C0lq602A.mjs";
import { n as spentByCategory, t as flows } from "./calc-CfYY_CoH.mjs";
import { n as SplitChart, t as FlowChart } from "./charts-DJqplFPt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/observe-MyMpf3zh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const mode = useFreev((s) => s.mode);
	const txs = useFreev((s) => s.txs);
	const accounts = useFreev((s) => s.accounts);
	const open = useFreev((s) => s.open);
	const flow = flows(txs, mode);
	const visible = accounts.filter((a) => inScope(a.scope, mode));
	const balance = visible.reduce((s, a) => s + a.balance, 0);
	const recent = [...txs].filter((t) => inScope(t.scope, mode)).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
	const split = spentByCategory(txs, mode);
	const snap = SNAP[mode];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Novembre 2026 · N° 11",
				title: "Tableau de bord",
				lede: "Le mois en cours, les échéances encore devant, et ce qui a déjà bougé.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/rapport",
					className: "inline-flex h-11 items-center border border-rule px-4 text-xs uppercase tracking-widest",
					children: "Rapport"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => open({ name: "tx" }),
					children: "Nouvelle opération"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid border-b border-rule lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-6 lg:col-span-5 lg:pr-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: ["Solde ", mode === "pro" ? "pro" : mode === "perso" ? "personnel" : "global"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-serif text-5xl tabular-nums md:text-6xl",
							children: money(balance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-sage",
							children: [pct(snap.delta), " vs mois dernier"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 border-t border-rule sm:grid-cols-3 lg:col-span-7 lg:border-t-0 lg:border-l",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Entrées",
							value: money(flow.inn),
							note: "Mois en cours",
							tone: "sage"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sorties",
							value: money(flow.out),
							note: "Mois en cours",
							tone: "clay"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Reste à vivre",
							value: money(flow.rest),
							note: "Entrées − sorties"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-10 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-10 lg:col-span-7 lg:border-r lg:border-rule lg:pr-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Échéancier"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-rule border-y border-rule",
						children: SCHEDULE.map((item) => {
							const passed = item.day < 19;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: [
										item.day,
										" novembre · ",
										passed ? "passé" : "à venir"
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { value: item.amount })]
							}, item.id);
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Activité récente"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/transactions",
							className: "text-xs uppercase tracking-widest text-copper",
							children: "Journal"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-rule",
						children: recent.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm",
									children: t.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: [
										dayLabel(t.date),
										" · ",
										t.category
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, {
								value: t.kind === "transfer" ? t.amount : t.amount,
								kind: t.kind
							})]
						}, t.id))
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-10 lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-mist",
								children: "Santé du mois"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-serif text-6xl tabular-nums",
								children: snap.health
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-xs text-sm text-mist",
								children: "Stable. Une charge d’énergie sort du rang, le reste suit le budget."
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Comptes"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-xs uppercase tracking-widest text-copper",
									onClick: () => open({ name: "pick-account" }),
									children: "Choisir"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-xs uppercase tracking-widest text-copper",
									onClick: () => open({ name: "accounts" }),
									children: "Gérer"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 divide-y divide-rule border-y border-rule",
							children: visible.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm",
									children: a.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: a.bank
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: money(a.balance)
								})]
							}, a.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl",
								children: "Répartition des sorties"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitChart, { data: split }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1",
								children: split.slice(0, 5).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums text-mist",
										children: money(c.value)
									})]
								}, c.name))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-l-2 border-copper pl-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-widest text-copper",
									children: "Alertes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm",
									children: "EDF a augmenté de 18 % par rapport à la moyenne."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm",
									children: "2 abonnements se renouvellent cette semaine."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/analytique",
									className: "mt-3 inline-block text-xs uppercase tracking-widest text-copper",
									children: "Voir l’analytique"
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-mist",
				children: [
					"Date de référence ",
					dayLabel(TODAY),
					"."
				]
			})
		]
	});
}
function Analytics() {
	const [span, setSpan] = (0, import_react.useState)(6);
	const mode = useFreev((s) => s.mode);
	const txs = useFreev((s) => s.txs);
	const flow = flows(txs, mode);
	const split = spentByCategory(txs, mode);
	const data = SERIES.slice(-span);
	const rate = flow.inn ? flow.rest / flow.inn * 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Analytique",
				title: "Ce que le mois raconte",
				lede: "Entrées, sorties, et les catégories qui pèsent — sur la période choisie.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: ["Période", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: span,
						onChange: (e) => setSpan(Number(e.target.value)),
						className: "ml-2 h-11 border border-rule bg-transparent px-2 text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 3,
							children: "3 mois"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 6,
							children: "6 mois"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid border-y border-rule sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Entrées",
						value: money(flow.inn),
						note: pct(6.4),
						tone: "sage"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sorties",
						value: money(flow.out),
						note: pct(-2.1),
						tone: "sage"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Épargne nette",
						value: money(flow.rest),
						note: "Novembre"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Taux d’épargne",
						value: `${rate.toFixed(1).replace(".", ",")} %`,
						note: "Du mois"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl",
				children: "Flux mensuel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowChart, { data })
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Catégories"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-rule border-y border-rule",
					children: split.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(c.value)
						})]
					}, c.name))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Novembre contre octobre"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "mt-4 w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs uppercase tracking-widest text-mist",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: " "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Nov."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Oct."
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-rule",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3",
									children: "Entrées"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums",
									children: money(HISTORY[0].inn)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums text-mist",
									children: money(HISTORY[1].inn)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-rule",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3",
									children: "Sorties"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums",
									children: money(HISTORY[0].out)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums text-mist",
									children: money(HISTORY[1].out)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-rule",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3",
									children: "Net"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums text-sage",
									children: money(HISTORY[0].inn - HISTORY[0].out)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular-nums text-mist",
									children: money(HISTORY[1].inn - HISTORY[1].out)
								})
							]
						})
					] })]
				})] })]
			})
		]
	});
}
function Business() {
	const invoices = useFreev((s) => s.invoices);
	const accounts = useFreev((s) => s.accounts);
	const open = useFreev((s) => s.open);
	const mark = useFreev((s) => s.markInvoice);
	const pro = accounts.find((a) => a.id === "pro");
	const waiting = invoices.filter((i) => i.status !== "payée");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Activité professionnelle",
				title: "Business",
				lede: "Chiffre facturé, charges, et ce que les clients vous doivent encore.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => open({ name: "invoice" }),
					children: "Nouvelle facture"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid border-y border-rule sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "CA du mois",
						value: money(8640),
						note: "Facturé"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Charges",
						value: money(3120),
						note: "Estimées",
						tone: "clay"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Résultat",
						value: money(5520),
						note: "Avant impôt",
						tone: "sage"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Trésorerie",
						value: money(12480),
						note: pro ? `dont Qonto ${money(pro.balance)}` : ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-10 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Clients"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-rule border-y border-rule",
					children: [
						[
							"Atelier Nord",
							"AN",
							"Payée · 2 400 €"
						],
						[
							"Studio Lina",
							"SL",
							waiting.some((i) => i.client === "Studio Lina") ? "En attente · 1 800 €" : "Payée · 1 800 €"
						],
						[
							"Maison Brume",
							"MB",
							"Payée · 960 €"
						]
					].map(([name, mark, last]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex size-10 items-center justify-center border border-rule font-serif text-sm",
							children: mark
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm",
								children: name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-mist",
								children: last
							})]
						})]
					}, name))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Factures"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-rule border-y border-rule",
					children: invoices.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								inv.number,
								" · ",
								inv.client
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: [
								dayLabel(inv.date),
								" · ",
								inv.status
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: money(inv.amount)
							}), inv.status !== "payée" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => {
									toast(useFreev.getState().remind(inv.id));
								},
								children: "Relancer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "primary",
								onClick: () => {
									mark(inv.id);
									toast("Facture marquée payée");
								},
								children: "Payée"
							})] }) : null]
						})]
					}, inv.id))
				})] })]
			})
		]
	});
}
function Report() {
	const mode = useFreev((s) => s.mode);
	const txs = useFreev((s) => s.txs);
	const flow = flows(txs, mode);
	const split = spentByCategory(txs, mode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Rapport mensuel",
			title: "Novembre, en une page",
			lede: "Le même récit que le tableau de bord, mis en forme pour être relu ou transmis.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => {
					const blob = new Blob([JSON.stringify({
						mois: "2026-11",
						entrees: flow.inn,
						sorties: flow.out,
						categories: split
					}, null, 2)], { type: "application/json" });
					const url = URL.createObjectURL(blob);
					const a = document.createElement("a");
					a.href = url;
					a.download = "freev-novembre-2026.json";
					a.click();
					URL.revokeObjectURL(url);
					toast("Rapport exporté");
				},
				children: "Exporter"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "border border-rule p-6 md:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-copper",
					children: "FREEV · Camille Morel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl",
					children: "Livre de novembre"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 max-w-2xl text-sm text-mist",
					children: [
						"Les entrées du mois s’établissent à ",
						money(flow.inn),
						", les sorties à ",
						money(flow.out),
						". Le reste à vivre est de ",
						money(flow.rest),
						". La santé du mois reste à ",
						SNAP[mode].health,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Entrées"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-serif text-3xl",
							children: money(flow.inn)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Sorties"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-serif text-3xl",
							children: money(flow.out)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Net"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-serif text-3xl",
							children: money(flow.rest)
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-10 font-serif text-2xl",
					children: "Sorties par poste"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-rule",
					children: split.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(c.value)
						})]
					}, c.name))
				})
			]
		})]
	});
}
//#endregion
export { Report as i, Business as n, Dashboard as r, Analytics as t };
