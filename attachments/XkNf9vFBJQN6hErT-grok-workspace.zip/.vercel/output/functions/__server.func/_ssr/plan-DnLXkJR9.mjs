import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as startOfMonth, i as format, o as eachDayOfInterval, r as getDay, s as endOfMonth, t as fr } from "../_libs/date-fns.mjs";
import { a as PageHead, d as money, n as Button, t as Amount } from "./ui-Bc5yfkUn.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as SCHEDULE, u as useFreev } from "./shell-C0lq602A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plan-DnLXkJR9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Planner() {
	const [cursor, setCursor] = (0, import_react.useState)(new Date(2026, 10, 1));
	const open = useFreev((s) => s.open);
	const duplicated = useFreev((s) => s.duplicated);
	const accounts = useFreev((s) => s.accounts);
	const key = format(cursor, "yyyy-MM");
	const days = eachDayOfInterval({
		start: startOfMonth(cursor),
		end: endOfMonth(cursor)
	});
	const lead = (getDay(startOfMonth(cursor)) + 6) % 7;
	const showSchedule = key === "2026-11" || duplicated.includes(key);
	const balance = accounts.reduce((s, a) => s + a.balance, 0);
	const ahead = SCHEDULE.filter((s) => key !== "2026-11" || s.day >= 19).reduce((s, item) => s + item.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Planification",
				title: "Planner",
				lede: "Le mois posé à plat : ce qui est passé, ce qui arrive, le solde projeté.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open({ name: "budget" }),
						children: "Budget"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open({ name: "duplicate" }),
						children: "Dupliquer le mois"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => open({ name: "tx" }),
						children: "Nouvelle opération"
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1)),
							children: "Mois précédent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-40 text-center font-serif text-2xl capitalize",
							children: format(cursor, "MMMM yyyy", { locale: fr })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1)),
							children: "Mois suivant"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mist",
					children: [
						"Solde projeté ",
						money(balance + (showSchedule ? ahead : 0)),
						duplicated.includes(key) ? " · mois dupliqué" : ""
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-7 text-center text-xs uppercase tracking-widest text-mist",
						children: [
							"Lun",
							"Mar",
							"Mer",
							"Jeu",
							"Ven",
							"Sam",
							"Dim"
						].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "py-2",
							children: d
						}, d))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-7 border-t border-l border-rule",
						children: [Array.from({ length: lead }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-16 border-r border-b border-rule bg-card-2" }, `e${i}`)), days.map((d) => {
							const dom = d.getDate();
							const marks = showSchedule ? SCHEDULE.filter((s) => s.day === dom) : [];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => open({
									name: "tx",
									date: format(d, "yyyy-MM-dd")
								}),
								className: "min-h-16 border-r border-b border-rule p-1 text-left hover:bg-card-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: key === "2026-11" && dom === 19 ? "inline-flex size-6 items-center justify-center bg-copper text-xs text-copper-ink" : "text-xs text-mist",
									children: dom
								}), marks.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block truncate text-xs text-copper",
									children: m.label
								}, m.id))]
							}, d.toISOString());
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl",
							children: "Échéances"
						}),
						showSchedule ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 divide-y divide-rule border-y border-rule",
							children: SCHEDULE.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm",
									children: s.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs uppercase tracking-widest text-mist",
									children: ["Jour ", s.day]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { value: s.amount })]
							}, s.id))
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-mist",
							children: "Aucune échéance posée sur ce mois. Dupliquez novembre pour les reprendre."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => open({ name: "opening" }),
								children: "Solde de départ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => open({ name: "transfer" }),
								children: "Entre comptes"
							})]
						})
					]
				})]
			})
		]
	});
}
function Smart() {
	const plans = useFreev((s) => s.plans);
	const toggle = useFreev((s) => s.togglePlan);
	const add = useFreev((s) => s.addPlan);
	const [name, setName] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("100");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Planification",
				title: "Smart",
				lede: "Des règles simples qui déplacent l’argent avant que vous ayez à y penser."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-rule border-y border-rule",
				children: plans.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mist",
						children: p.detail
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs uppercase tracking-widest text-mist",
								children: p.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: money(p.amount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => toggle(p.id),
								children: p.status === "actif" ? "Pause" : "Activer"
							})
						]
					})]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-l-2 border-copper pl-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-copper",
							children: "Suggestion"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: "Les abonnements pèsent sur le mois. Mettre Spotify en pause libère 11 € sans toucher au loyer."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: "Un virement automatique de 200 € reste possible le 30, après le salaire."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit: (e) => {
						e.preventDefault();
						if (!name.trim()) return;
						add({
							name: name.trim(),
							detail: "Plan créé à la main",
							amount: Number(amount) || 0,
							status: "actif"
						});
						setName("");
						toast("Plan ajouté");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-mist",
							children: "Nouveau plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Nom",
							className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							className: "w-full border-b border-rule bg-transparent py-2 text-sm outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "primary",
							children: "Créer le plan"
						})
					]
				})]
			})
		]
	});
}
function Savings() {
	const goals = useFreev((s) => s.goals);
	const open = useFreev((s) => s.open);
	const remove = useFreev((s) => s.removeGoal);
	const accounts = useFreev((s) => s.accounts);
	const names = (0, import_react.useMemo)(() => Object.fromEntries(accounts.map((a) => [a.id, a.name])), [accounts]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Planification",
			title: "Épargne",
			lede: "Chaque objectif a une cible, une échéance, et le compte qui le porte.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => open({ name: "goal" }),
				children: "Nouvel objectif"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-6",
			children: goals.map((g) => {
				const ratio = g.target ? Math.min(100, Math.round(g.current / g.target * 100)) : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-b border-rule pb-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-serif text-2xl",
								children: g.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs uppercase tracking-widest text-mist",
								children: [
									names[g.accountId] ?? "Compte",
									" · échéance ",
									g.due
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "tabular-nums",
								children: [
									money(g.current),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-mist",
										children: ["/ ", money(g.target)]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1 bg-card-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-1 bg-copper",
								style: { width: `${ratio}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => open({
									name: "goal",
									id: g.id
								}),
								children: "Ajuster"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => remove(g.id),
								children: "Retirer"
							})]
						})
					]
				}, g.id);
			})
		})]
	});
}
function Debts() {
	const debts = useFreev((s) => s.debts);
	const open = useFreev((s) => s.open);
	const pay = useFreev((s) => s.payDebt);
	const total = debts.reduce((s, d) => s + d.remaining, 0);
	const monthly = debts.reduce((s, d) => s + d.monthly, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "Planification",
				title: "Dettes",
				lede: "Ce qu’il reste à rembourser, et le rythme mensuel.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => open({ name: "debt" }),
					children: "Nouvelle dette"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mist",
				children: [
					"Reste ",
					money(total),
					" · mensualités ",
					money(monthly)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-rule border-y border-rule",
				children: debts.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: d.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-widest text-mist",
						children: [
							d.rate.toLocaleString("fr-FR"),
							" % · fin ",
							d.end,
							" · ",
							money(d.monthly),
							" / mois"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-serif text-2xl tabular-nums",
								children: money(d.remaining)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => pay(d.id),
								children: "Rembourser"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => open({
									name: "debt",
									id: d.id
								}),
								children: "Modifier"
							})
						]
					})]
				}, d.id))
			})
		]
	});
}
//#endregion
export { Smart as i, Planner as n, Savings as r, Debts as t };
