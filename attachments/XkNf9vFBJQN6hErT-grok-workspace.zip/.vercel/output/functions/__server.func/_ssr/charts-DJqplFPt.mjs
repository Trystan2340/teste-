import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CartesianGrid, c as Cell, i as XAxis, l as ResponsiveContainer, n as BarChart, o as Bar, r as YAxis, s as Pie, t as PieChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/charts-DJqplFPt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tip = { contentStyle: {
	background: "var(--card)",
	border: "1px solid var(--rule)",
	borderRadius: 0,
	color: "var(--ink)",
	fontSize: 12
} };
function useReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	return ready;
}
function FlowChart({ data }) {
	if (!useReady()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				barGap: 2,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--rule)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "m",
						tick: {
							fill: "var(--mist)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tick: {
							fill: "var(--mist)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false,
						width: 40
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						...tip,
						cursor: { fill: "var(--card-2)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "inn",
						name: "Entrées",
						fill: "var(--sage)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "out",
						name: "Sorties",
						fill: "var(--copper)"
					})
				]
			})
		})
	});
}
var SLICE = [
	"var(--copper)",
	"var(--sage)",
	"var(--mist)",
	"var(--clay)",
	"var(--ink)"
];
function SplitChart({ data }) {
	const ready = useReady();
	const top = data.slice(0, 5);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-52 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
				data: top,
				dataKey: "value",
				nameKey: "name",
				innerRadius: 48,
				outerRadius: 72,
				stroke: "var(--canvas)",
				paddingAngle: 2,
				children: top.map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: SLICE[i % SLICE.length] }, entry.name))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { ...tip })] })
		})
	});
}
//#endregion
export { SplitChart as n, FlowChart as t };
