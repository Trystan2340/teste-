import { a as PublicSubs } from "./public-DNah83pO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/abonnements-recurrents-CFCgeCCw.js
var SplitComponent = PublicSubs;
//#endregion
export { SplitComponent as component };
