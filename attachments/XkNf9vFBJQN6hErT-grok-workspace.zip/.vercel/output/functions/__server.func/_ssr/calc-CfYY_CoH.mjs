import { l as inScope } from "./shell-C0lq602A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calc-CfYY_CoH.js
function flows(txs, mode, month = "2026-11") {
	const rows = txs.filter((t) => t.date.startsWith(month) && !t.pending && t.kind !== "transfer" && inScope(t.scope, mode));
	const inn = rows.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
	const out = rows.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);
	return {
		inn,
		out,
		rest: inn - out,
		rows
	};
}
function spentByCategory(txs, mode, month = "2026-11") {
	const map = /* @__PURE__ */ new Map();
	for (const t of txs) {
		if (!t.date.startsWith(month) || t.kind !== "expense" || t.pending || !inScope(t.scope, mode)) continue;
		map.set(t.category, (map.get(t.category) ?? 0) + Math.abs(t.amount));
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		value: Math.round(value * 100) / 100
	})).sort((a, b) => b.value - a.value);
}
//#endregion
export { spentByCategory as n, flows as t };
