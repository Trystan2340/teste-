import { n as Login } from "./gate-Be8AxGo5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/connexion-CZb8Y1MQ.js
var SplitComponent = Login;
//#endregion
export { SplitComponent as component };
