import { i as __toESM, n as __exportAll } from "../_runtime.mjs";
import { C as useRouter, X as require_jsx_runtime, Y as require_react, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, p as HeadContent, v as lazyRouteComponent, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-cpWNqwpy.js
var router_cpWNqwpy_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-1RNhrDUW.css";
var Route$30 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "FREEV" },
			{
				name: "description",
				content: "FREEV — livre de comptes personnel et professionnel."
			},
			{
				name: "theme-color",
				content: "#12110f"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,620;1,9..144,500&family=Outfit:wght@400;500;600&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fr",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: "try{var t=JSON.parse(localStorage.getItem('freev')||'{}');var th=t.state&&t.state.theme;var d=window.matchMedia('(prefers-color-scheme: dark)').matches;var r=th==='system'?(d?'ink':'paper'):(th||'ink');document.documentElement.dataset.theme=r;}catch(e){}" } }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "bottom-right" })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$29 = () => import("./routes-DJL7sM4r.mjs");
var Route$29 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Tableau de bord — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./abonnements-DfZfA6ge.mjs");
var Route$28 = createFileRoute("/abonnements")({
	head: () => ({ meta: [{ title: "Abonnements — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./abonnements-recurrents-CFCgeCCw.mjs");
var Route$27 = createFileRoute("/abonnements-recurrents")({
	head: () => ({ meta: [{ title: "Abonnements — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./aide-B0vNjlAe.mjs");
var Route$26 = createFileRoute("/aide")({
	head: () => ({ meta: [{ title: "Aide — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./analytique-DMnCMYdg.mjs");
var Route$25 = createFileRoute("/analytique")({
	head: () => ({ meta: [{ title: "Analytique — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./budget-personnel-DPXGpVSo.mjs");
var Route$24 = createFileRoute("/budget-personnel")({
	head: () => ({ meta: [{ title: "Budget personnel — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./business-BcUgMtag.mjs");
var Route$23 = createFileRoute("/business")({
	head: () => ({ meta: [{ title: "Business — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./compte-DzQ__E4K.mjs");
var Route$22 = createFileRoute("/compte")({
	head: () => ({ meta: [{ title: "Mon compte — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./conditions-Di88ifbw.mjs");
var Route$21 = createFileRoute("/conditions")({
	head: () => ({ meta: [{ title: "Conditions — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./confidentialite-BMDTMyLf.mjs");
var Route$20 = createFileRoute("/confidentialite")({
	head: () => ({ meta: [{ title: "Confidentialité — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./configuration-CVBmkILz.mjs");
var Route$19 = createFileRoute("/configuration")({
	head: () => ({ meta: [{ title: "Configuration — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./connexion-CZb8Y1MQ.mjs");
var Route$18 = createFileRoute("/connexion")({
	head: () => ({ meta: [{ title: "Connexion — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./controle-m5a0LdnB.mjs");
var Route$17 = createFileRoute("/controle")({
	head: () => ({ meta: [{ title: "Contrôle mensuel — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./dettes-vOMUqUu6.mjs");
var Route$16 = createFileRoute("/dettes")({
	head: () => ({ meta: [{ title: "Dettes — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./epargne-DmAE2EEU.mjs");
var Route$15 = createFileRoute("/epargne")({
	head: () => ({ meta: [{ title: "Épargne — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./historique-BTjMLw20.mjs");
var Route$14 = createFileRoute("/historique")({
	head: () => ({ meta: [{ title: "Historique — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./inscription-lSwfaPcj.mjs");
var Route$13 = createFileRoute("/inscription")({
	head: () => ({ meta: [{ title: "Inscription — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./parametres-BxZrJxwo.mjs");
var Route$12 = createFileRoute("/parametres")({
	head: () => ({ meta: [{ title: "Paramètres — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./parametres-pro-BAfZyabZ.mjs");
var Route$11 = createFileRoute("/parametres-pro")({
	head: () => ({ meta: [{ title: "Paramètres pro — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./patrimoine-DZo87G7G.mjs");
var Route$10 = createFileRoute("/patrimoine")({
	head: () => ({ meta: [{ title: "Patrimoine — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./planner-BYK36GNF.mjs");
var Route$9 = createFileRoute("/planner")({
	head: () => ({ meta: [{ title: "Planner — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./rapport-BHXHn5Ry.mjs");
var Route$8 = createFileRoute("/rapport")({
	head: () => ({ meta: [{ title: "Rapport — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./recurrences-CTGFULSm.mjs");
var Route$7 = createFileRoute("/recurrences")({
	head: () => ({ meta: [{ title: "Récurrences — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./regles-DWzq4vvC.mjs");
var Route$6 = createFileRoute("/regles")({
	head: () => ({ meta: [{ title: "Règles — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./scanner-CqZ1TOo0.mjs");
var Route$5 = createFileRoute("/scanner")({
	head: () => ({ meta: [{ title: "Scanner — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./securite-RmmUCWG3.mjs");
var Route$4 = createFileRoute("/securite")({
	head: () => ({ meta: [{ title: "Sécurité — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./smart-DDZqRRE_.mjs");
var Route$3 = createFileRoute("/smart")({
	head: () => ({ meta: [{ title: "Smart — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./suivi-depenses-DB1xR-rF.mjs");
var Route$2 = createFileRoute("/suivi-depenses")({
	head: () => ({ meta: [{ title: "Suivi des dépenses — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./transactions-Cdzy_qG0.mjs");
var Route$1 = createFileRoute("/transactions")({
	head: () => ({ meta: [{ title: "Transactions — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tresorerie-CgMUyZy8.mjs");
var Route = createFileRoute("/tresorerie")({
	head: () => ({ meta: [{ title: "Trésorerie — FREEV" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$29.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$30
	}),
	AbonnementsRoute: Route$28.update({
		id: "/abonnements",
		path: "/abonnements",
		getParentRoute: () => Route$30
	}),
	AbonnementsRecurrentsRoute: Route$27.update({
		id: "/abonnements-recurrents",
		path: "/abonnements-recurrents",
		getParentRoute: () => Route$30
	}),
	AideRoute: Route$26.update({
		id: "/aide",
		path: "/aide",
		getParentRoute: () => Route$30
	}),
	AnalytiqueRoute: Route$25.update({
		id: "/analytique",
		path: "/analytique",
		getParentRoute: () => Route$30
	}),
	BudgetPersonnelRoute: Route$24.update({
		id: "/budget-personnel",
		path: "/budget-personnel",
		getParentRoute: () => Route$30
	}),
	BusinessRoute: Route$23.update({
		id: "/business",
		path: "/business",
		getParentRoute: () => Route$30
	}),
	CompteRoute: Route$22.update({
		id: "/compte",
		path: "/compte",
		getParentRoute: () => Route$30
	}),
	ConditionsRoute: Route$21.update({
		id: "/conditions",
		path: "/conditions",
		getParentRoute: () => Route$30
	}),
	ConfidentialiteRoute: Route$20.update({
		id: "/confidentialite",
		path: "/confidentialite",
		getParentRoute: () => Route$30
	}),
	ConfigurationRoute: Route$19.update({
		id: "/configuration",
		path: "/configuration",
		getParentRoute: () => Route$30
	}),
	ConnexionRoute: Route$18.update({
		id: "/connexion",
		path: "/connexion",
		getParentRoute: () => Route$30
	}),
	ControleRoute: Route$17.update({
		id: "/controle",
		path: "/controle",
		getParentRoute: () => Route$30
	}),
	DettesRoute: Route$16.update({
		id: "/dettes",
		path: "/dettes",
		getParentRoute: () => Route$30
	}),
	EpargneRoute: Route$15.update({
		id: "/epargne",
		path: "/epargne",
		getParentRoute: () => Route$30
	}),
	HistoriqueRoute: Route$14.update({
		id: "/historique",
		path: "/historique",
		getParentRoute: () => Route$30
	}),
	InscriptionRoute: Route$13.update({
		id: "/inscription",
		path: "/inscription",
		getParentRoute: () => Route$30
	}),
	ParametresRoute: Route$12.update({
		id: "/parametres",
		path: "/parametres",
		getParentRoute: () => Route$30
	}),
	ParametresProRoute: Route$11.update({
		id: "/parametres-pro",
		path: "/parametres-pro",
		getParentRoute: () => Route$30
	}),
	PatrimoineRoute: Route$10.update({
		id: "/patrimoine",
		path: "/patrimoine",
		getParentRoute: () => Route$30
	}),
	PlannerRoute: Route$9.update({
		id: "/planner",
		path: "/planner",
		getParentRoute: () => Route$30
	}),
	RapportRoute: Route$8.update({
		id: "/rapport",
		path: "/rapport",
		getParentRoute: () => Route$30
	}),
	RecurrencesRoute: Route$7.update({
		id: "/recurrences",
		path: "/recurrences",
		getParentRoute: () => Route$30
	}),
	ReglesRoute: Route$6.update({
		id: "/regles",
		path: "/regles",
		getParentRoute: () => Route$30
	}),
	ScannerRoute: Route$5.update({
		id: "/scanner",
		path: "/scanner",
		getParentRoute: () => Route$30
	}),
	SecuriteRoute: Route$4.update({
		id: "/securite",
		path: "/securite",
		getParentRoute: () => Route$30
	}),
	SmartRoute: Route$3.update({
		id: "/smart",
		path: "/smart",
		getParentRoute: () => Route$30
	}),
	SuiviDepensesRoute: Route$2.update({
		id: "/suivi-depenses",
		path: "/suivi-depenses",
		getParentRoute: () => Route$30
	}),
	TransactionsRoute: Route$1.update({
		id: "/transactions",
		path: "/transactions",
		getParentRoute: () => Route$30
	}),
	TresorerieRoute: Route.update({
		id: "/tresorerie",
		path: "/tresorerie",
		getParentRoute: () => Route$30
	})
};
var routeTree = Route$30._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getRouter, router_cpWNqwpy_exports as t };
