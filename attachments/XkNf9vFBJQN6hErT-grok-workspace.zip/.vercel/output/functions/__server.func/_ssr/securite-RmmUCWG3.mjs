import { X as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Shell } from "./shell-C0lq602A.mjs";
import { s as Security } from "./system-BdnP-kWr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/securite-RmmUCWG3.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Security, {}) });
};
//#endregion
export { SplitComponent as component };
