import { n as PublicBudget } from "./public-DNah83pO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/budget-personnel-DPXGpVSo.js
var SplitComponent = PublicBudget;
//#endregion
export { SplitComponent as component };
