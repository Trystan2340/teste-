import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/public-DNah83pO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/budget-personnel",
		label: "Budget"
	},
	{
		to: "/suivi-depenses",
		label: "Dépenses"
	},
	{
		to: "/abonnements-recurrents",
		label: "Abonnements"
	},
	{
		to: "/tresorerie",
		label: "Trésorerie"
	}
];
function Site({ kicker, title, lede, points }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center gap-4 border-b border-rule px-5 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "font-serif text-2xl",
						children: "FREEV"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-wrap gap-4 text-xs uppercase tracking-widest text-mist",
						children: LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: l.to,
							className: "hover:text-ink",
							children: l.label
						}, l.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "ml-auto border border-copper px-3 py-2 text-xs uppercase tracking-widest text-copper",
						children: "Ouvrir l’app"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-8 border-b border-rule px-5 py-16 lg:grid-cols-12 lg:px-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-copper lg:col-span-3",
						children: kicker
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-9",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "max-w-3xl font-serif text-5xl leading-none md:text-6xl",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-sm text-mist",
							children: lede
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid border-b border-rule lg:grid-cols-3",
					children: points.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "border-b border-rule p-6 lg:border-r lg:border-b-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs uppercase tracking-widest text-mist",
								children: ["0", i + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-serif text-2xl",
								children: p.t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mist",
								children: p.d
							})
						]
					}, p.t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-8 px-5 py-16 lg:grid-cols-12 lg:px-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-3xl lg:col-span-4",
						children: "Tarifs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 sm:grid-cols-3 lg:col-span-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, {
								name: "Essai",
								price: "0 €",
								note: "14 jours, sans carte."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, {
								name: "Personnel",
								price: "6 €",
								note: "Budget, récurrences, planner."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, {
								name: "Professionnel",
								price: "14 €",
								note: "Factures, clients, trésorerie."
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "grid gap-6 border-t border-rule px-5 py-10 text-sm text-mist md:grid-cols-3 lg:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-xl text-ink",
						children: "FREEV"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: "Le livre de comptes personnel et professionnel."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-1",
						children: LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: l.to,
							className: "block hover:text-ink",
							children: l.label
						}, l.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/confidentialite",
								className: "block hover:text-ink",
								children: "Confidentialité"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/conditions",
								className: "block hover:text-ink",
								children: "Conditions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "mailto:bonjour@freev.app",
								className: "block hover:text-ink",
								children: "bonjour@freev.app"
							})
						]
					})
				]
			})
		]
	});
}
function Price({ name, price, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-copper pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-mist",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-serif text-4xl",
				children: price
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mist",
				children: note
			})
		]
	});
}
function Faq() {
	const items = [
		["Faut-il relier une banque ?", "Non. Vous pouvez tenir le livre à la main, scanner un reçu, ou ajouter un compte avec son solde."],
		["Personnel et pro ensemble ?", "Oui. Le sélecteur en haut filtre le journal. Les factures restent dans Business."],
		["Où sont les données ?", "Dans cette démo, sur cet appareil. Rien n’est envoyé à une banque."],
		["Puis-je exporter ?", "Oui, depuis Paramètres ou depuis le rapport du mois."]
	];
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "border-t border-rule px-5 py-16 lg:px-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-3xl",
			children: "Questions"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 max-w-3xl divide-y divide-rule border-y border-rule",
			children: items.map(([q, a], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center justify-between py-4 text-left",
				onClick: () => setOpen(i),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-copper",
					children: open === i ? "–" : "+"
				})]
			}), open === i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pb-4 text-sm text-mist",
				children: a
			}) : null] }, q))
		})]
	});
}
function PublicBudget() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {
		kicker: "Budget personnel",
		title: "Votre mois, tenu comme un livre de comptes.",
		lede: "Un solde, des échéances, un reste à vivre. Pas un tableau qui crie.",
		points: [
			{
				t: "Le mois d’un regard",
				d: "Entrées, sorties, reste. La santé du mois en un chiffre."
			},
			{
				t: "Échéancier",
				d: "Loyer, énergie, salaire : passé ou encore devant."
			},
			{
				t: "Contrôle",
				d: "Avant de tourner la page, anomalies et budget."
			}
		]
	});
}
function PublicSpend() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {
		kicker: "Suivi des dépenses",
		title: "Chaque euro a une ligne.",
		lede: "Catégories, comptes, recherche. Le journal se filtre sans se déguiser.",
		points: [
			{
				t: "Journal",
				d: "Date, libellé, catégorie, compte, montant."
			},
			{
				t: "Filtres",
				d: "Par type, par compte, par mot."
			},
			{
				t: "Reçu",
				d: "Une photo devient une ligne à confirmer."
			}
		]
	});
}
function PublicSubs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {
		kicker: "Abonnements",
		title: "Ce qui se renouvelle, sans surprise.",
		lede: "Prix, date, pause, résiliation, essai. Le total du mois est écrit en clair.",
		points: [
			{
				t: "Liste",
				d: "Netflix, salle, cloud, outils."
			},
			{
				t: "Essais",
				d: "Une date de fin avant le prélèvement."
			},
			{
				t: "Règles",
				d: "Un gros abonnement peut demander confirmation."
			}
		]
	});
}
function PublicCash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {
		kicker: "Trésorerie",
		title: "La trésorerie, lisible.",
		lede: "Factures, clients, charges. Ce qui est payé et ce qui attend.",
		points: [
			{
				t: "Factures",
				d: "Créer, relancer, marquer payée."
			},
			{
				t: "Clients",
				d: "Le dernier mouvement de chacun."
			},
			{
				t: "Résultat",
				d: "CA, charges, ce qu’il reste."
			}
		]
	});
}
function Legal({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-canvas text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-4 border-b border-rule px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/budget-personnel",
				className: "font-serif text-2xl",
				children: "FREEV"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "ml-auto text-xs uppercase tracking-widest text-copper",
				children: "Ouvrir l’app"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "max-w-2xl px-5 py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-5xl",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-4 text-sm text-mist",
				children
			})]
		})]
	});
}
function Privacy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
		title: "Confidentialité",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "FREEV tient un livre de comptes. Dans cette maquette, les opérations, objectifs et réglages restent dans le navigateur, sur cet appareil." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Aucun relevé bancaire n’est demandé. Les reçus que vous déposez ne quittent pas la page : seule une lecture locale propose un montant." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "L’export JSON vous appartient. Effacer les données vide le journal local sans conserver de copie." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Contact : bonjour@freev.app." })
		]
	});
}
function Terms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Legal, {
		title: "Conditions",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "FREEV est un outil de suivi. Il ne fournit pas de conseil en investissement, ni un service de paiement." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "L’essai dure 14 jours. Le tarif Personnel est de 6 € par mois, le tarif Professionnel de 14 € par mois. Vous pouvez arrêter avant le renouvellement." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Les chiffres affichés dépendent de ce que vous saisissez. Un solde projeté n’est pas une garantie bancaire." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Le droit applicable est le droit français." })
		]
	});
}
//#endregion
export { PublicSubs as a, PublicSpend as i, PublicBudget as n, Terms as o, PublicCash as r, Privacy as t };
