import { r as Signup } from "./gate-Be8AxGo5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inscription-lSwfaPcj.js
var SplitComponent = Signup;
//#endregion
export { SplitComponent as component };
