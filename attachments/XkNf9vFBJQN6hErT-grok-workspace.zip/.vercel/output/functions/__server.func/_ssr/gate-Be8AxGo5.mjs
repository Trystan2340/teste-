import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_jsx_runtime, Y as require_react, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button } from "./ui-Bc5yfkUn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gate-Be8AxGo5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Frame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-dvh lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex flex-col justify-between bg-card px-6 py-8 text-ink lg:col-span-5 lg:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "font-serif text-3xl",
					children: "FREEV"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-4xl leading-tight md:text-5xl",
					children: "Le mois, tenu comme un livre."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-8 space-y-3 text-sm text-mist",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "01 — Personnel, pro, ou les deux" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "02 — Journal, échéances, factures" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "03 — Contrôle avant de tourner la page" })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: "Paris · novembre 2026"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "flex items-center bg-canvas px-6 py-10 lg:col-span-7 lg:px-16",
			children
		})]
	});
}
function Login() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("camille@freev.app");
	const [password, setPassword] = (0, import_react.useState)("livre-de-comptes");
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "w-full max-w-md",
		onSubmit: (e) => {
			e.preventDefault();
			if (!email.includes("@") || password.length < 4) {
				setError("E-mail et mot de passe requis.");
				return;
			}
			navigate({ to: "/" });
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Connexion"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mist",
				children: "Reprendre le livre là où vous l’avez laissé."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: "E-mail"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: email,
					onChange: (e) => setEmail(e.target.value),
					className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: "Mot de passe"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-clay",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "primary",
				className: "mt-6",
				children: "Entrer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm text-mist",
				children: [
					"Pas encore de livre ?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/inscription",
						className: "text-copper",
						children: "Créer un compte"
					})
				]
			})
		]
	}) });
}
function Signup() {
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "w-full max-w-md",
		onSubmit: (e) => {
			e.preventDefault();
			if (name.trim().length < 2 || !email.includes("@") || password.length < 8) {
				setError("Nom, e-mail, et huit caractères minimum.");
				return;
			}
			navigate({ to: "/configuration" });
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Inscription"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mist",
				children: "Un compte, deux vies d’argent si vous le souhaitez."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: "Nom"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (e) => setName(e.target.value),
					className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: "E-mail"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: email,
					onChange: (e) => setEmail(e.target.value),
					className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest text-mist",
					children: "Mot de passe"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none"
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-clay",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "primary",
				className: "mt-6",
				children: "Continuer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm text-mist",
				children: [
					"Déjà inscrit ?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/connexion",
						className: "text-copper",
						children: "Connexion"
					})
				]
			})
		]
	}) });
}
function Configure() {
	const navigate = useNavigate();
	const [kind, setKind] = (0, import_react.useState)(null);
	const [done, setDone] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-4xl",
				children: "Configuration"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mist",
				children: "Particulier ou professionnel. Vous pourrez tenir les deux ensuite."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setKind("perso"),
					className: kind === "perso" ? "border border-copper p-4 text-left" : "border border-rule p-4 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-serif text-2xl",
						children: "Particulier"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-mist",
						children: "Budget, échéances, épargne."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setKind("pro"),
					className: kind === "pro" ? "border border-copper p-4 text-left" : "border border-rule p-4 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-serif text-2xl",
						children: "Professionnel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-mist",
						children: "Factures, clients, trésorerie."
					})]
				})]
			}),
			kind === "perso" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					setDone("Livre personnel ouvert.");
					navigate({ to: "/" });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["Revenu mensuel estimé", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none",
							defaultValue: "3200"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["Loyer", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none",
							defaultValue: "890"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						children: "Ouvrir le livre"
					})
				]
			}) : null,
			kind === "pro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					setDone("Livre professionnel ouvert.");
					navigate({ to: "/business" });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["Nom commercial", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none",
							defaultValue: "Camille Morel Studio"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm",
						children: ["SIRET", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "mt-1 w-full border-b border-rule bg-transparent py-2 outline-none",
							defaultValue: "849 302 118 00024"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						children: "Ouvrir le livre"
					})
				]
			}) : null,
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-sage",
				children: done
			}) : null
		]
	}) });
}
//#endregion
export { Login as n, Signup as r, Configure as t };
