import { i as PublicSpend } from "./public-DNah83pO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/suivi-depenses-DB1xR-rF.js
var SplitComponent = PublicSpend;
//#endregion
export { SplitComponent as component };
