import { i as __toESM } from "../_runtime.mjs";
import { X as require_jsx_runtime, Y as require_react, m as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Toggle, i as Field, l as cn, n as Button, o as Select, p as uid } from "./ui-Bc5yfkUn.mjs";
import { S as ArrowLeftRight, _ as CircleHelp, a as Settings, b as Briefcase, c as Repeat, d as LayoutDashboard, f as Landmark, g as ClipboardCheck, h as CreditCard, i as Shield, l as PiggyBank, m as Gem, o as Search, p as History, r as Sparkles, s as Scale, t as X, u as Menu, v as ChartLine, x as Bell, y as CalendarRange } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-C0lq602A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TODAY = "2026-11-19";
var ACCOUNTS = [
	{
		id: "courant",
		name: "Compte courant",
		bank: "BoursoBank",
		balance: 4280,
		scope: "perso",
		kind: "courant"
	},
	{
		id: "livret",
		name: "Livret A",
		bank: "BoursoBank",
		balance: 8640,
		scope: "perso",
		kind: "epargne"
	},
	{
		id: "pro",
		name: "Compte pro",
		bank: "Qonto",
		balance: 5500,
		scope: "pro",
		kind: "pro"
	}
];
var CATEGORIES = [
	"Logement",
	"Alimentation",
	"Transport",
	"Abonnements",
	"Énergie",
	"Santé",
	"Loisirs",
	"Maison",
	"Impôts",
	"Charges",
	"Matériel",
	"Prestation",
	"Revenus",
	"Autre"
];
function row(id, date, label, category, accountId, amount, scope, extra = {}) {
	return {
		id,
		date,
		label,
		category,
		accountId,
		amount,
		scope,
		kind: amount < 0 ? "expense" : "income",
		recurring: false,
		pending: false,
		...extra
	};
}
var SEED_TX = [
	row("t1", "2026-11-18", "Courses Monoprix", "Alimentation", "courant", -64.2, "perso"),
	row("t2", "2026-11-17", "Atelier Nord", "Prestation", "pro", 2400, "pro", { logo: "AN" }),
	row("t3", "2026-11-17", "Cadeau", "Loisirs", "courant", -35, "perso"),
	row("t4", "2026-11-16", "Essence", "Transport", "courant", -52, "perso"),
	row("t5", "2026-11-15", "URSSAF", "Charges", "pro", -820, "pro", { recurring: true }),
	row("t6", "2026-11-15", "Assurance auto", "Transport", "courant", -62, "perso", { recurring: true }),
	row("t7", "2026-11-14", "Maison Brume", "Prestation", "pro", 960, "pro", { logo: "MB" }),
	row("t8", "2026-11-14", "Courses bio", "Alimentation", "courant", -73.5, "perso"),
	row("t9", "2026-11-13", "Pharmacie", "Santé", "courant", -22, "perso"),
	row("t10", "2026-11-12", "Netflix", "Abonnements", "courant", -15.9, "perso", {
		recurring: true,
		logo: "N"
	}),
	row("t11", "2026-11-11", "Restaurant", "Loisirs", "courant", -46, "perso"),
	row("t12", "2026-11-10", "Courses Carrefour", "Alimentation", "courant", -128.4, "perso"),
	row("t13", "2026-11-09", "Comptable", "Charges", "pro", -150, "pro"),
	row("t14", "2026-11-09", "Spotify", "Abonnements", "courant", -11, "perso", {
		recurring: true,
		logo: "S"
	}),
	row("t15", "2026-11-08", "Internet", "Abonnements", "courant", -30, "perso", { recurring: true }),
	row("t16", "2026-11-08", "Remboursement impôts", "Revenus", "courant", 1800, "perso"),
	row("t17", "2026-11-07", "Logiciels", "Abonnements", "pro", -55, "pro", { recurring: true }),
	row("t18", "2026-11-06", "Fournitures", "Matériel", "pro", -140, "pro"),
	row("t19", "2026-11-06", "Prime", "Revenus", "courant", 1200, "perso"),
	row("t20", "2026-11-05", "EDF", "Énergie", "courant", -74, "perso", { recurring: true }),
	row("t21", "2026-11-04", "Salle de sport", "Abonnements", "courant", -39.9, "perso", { recurring: true }),
	row("t22", "2026-11-04", "Leboncoin", "Revenus", "courant", 220, "perso"),
	row("t23", "2026-11-03", "Mutuelle", "Santé", "courant", -48, "perso", { recurring: true }),
	row("t24", "2026-11-03", "Sécurité sociale", "Revenus", "courant", 260, "perso"),
	row("t25", "2026-11-02", "Coworking", "Charges", "pro", -160, "pro"),
	row("t26", "2026-11-02", "Shopping", "Loisirs", "courant", -180, "perso"),
	row("t27", "2026-11-01", "Loyer", "Logement", "courant", -890, "perso", { recurring: true }),
	row("t28", "2026-11-01", "Navigo", "Transport", "courant", -86.1, "perso", { recurring: true }),
	row("t29", "2026-11-01", "Impôts locaux", "Impôts", "courant", -480, "perso"),
	row("t30", "2026-11-11", "Équipement maison", "Maison", "courant", -390, "perso"),
	row("t31", "2026-11-07", "Déjeuner client", "Loisirs", "courant", -72, "perso"),
	row("t32", "2026-11-13", "Divers", "Autre", "courant", -90, "perso")
];
var SCHEDULE = [
	{
		id: "s1",
		day: 1,
		label: "Loyer",
		amount: -890,
		category: "Logement"
	},
	{
		id: "s2",
		day: 5,
		label: "EDF",
		amount: -74,
		category: "Énergie"
	},
	{
		id: "s3",
		day: 12,
		label: "Netflix",
		amount: -15.9,
		category: "Abonnements"
	},
	{
		id: "s4",
		day: 21,
		label: "iCloud",
		amount: -2.99,
		category: "Abonnements"
	},
	{
		id: "s5",
		day: 28,
		label: "Salaire",
		amount: 3200,
		category: "Revenus"
	},
	{
		id: "s6",
		day: 30,
		label: "Épargne auto",
		amount: -200,
		category: "Épargne"
	}
];
var SERIES = [
	{
		m: "Juin",
		inn: 6100,
		out: 4800
	},
	{
		m: "Juil.",
		inn: 6400,
		out: 5100
	},
	{
		m: "Août",
		inn: 5900,
		out: 4700
	},
	{
		m: "Sept.",
		inn: 6400,
		out: 5100
	},
	{
		m: "Oct.",
		inn: 6510,
		out: 4480
	},
	{
		m: "Nov.",
		inn: 6840,
		out: 4215
	}
];
var HISTORY = [
	{
		id: "2026-11",
		label: "Novembre 2026",
		inn: 6840,
		out: 4215
	},
	{
		id: "2026-10",
		label: "Octobre 2026",
		inn: 6510,
		out: 4480
	},
	{
		id: "2026-09",
		label: "Septembre 2026",
		inn: 6400,
		out: 5100
	},
	{
		id: "2026-08",
		label: "Août 2026",
		inn: 5900,
		out: 4700
	},
	{
		id: "2026-07",
		label: "Juillet 2026",
		inn: 6400,
		out: 5100
	},
	{
		id: "2026-06",
		label: "Juin 2026",
		inn: 6100,
		out: 4800
	}
];
var GOALS = [
	{
		id: "g1",
		name: "Voyage Japon",
		current: 2400,
		target: 4e3,
		due: "2027-06-01",
		accountId: "livret"
	},
	{
		id: "g2",
		name: "Apport appartement",
		current: 8600,
		target: 2e4,
		due: "2028-12-01",
		accountId: "livret"
	},
	{
		id: "g3",
		name: "Fonds de sécurité",
		current: 3200,
		target: 3e3,
		due: "2026-12-01",
		accountId: "livret"
	}
];
var DEBTS = [{
	id: "d1",
	name: "Crédit auto",
	remaining: 4800,
	monthly: 210,
	rate: 3.2,
	end: "2028-06-01"
}, {
	id: "d2",
	name: "Prêt familial",
	remaining: 1200,
	monthly: 100,
	rate: 0,
	end: "2027-11-01"
}];
var RULES = [
	{
		id: "r1",
		name: "Alerte loyer",
		when: "Logement dépasse 900 €",
		action: "Notifier",
		on: true
	},
	{
		id: "r2",
		name: "Épargne au salaire",
		when: "Salaire reçu",
		action: "Virer 200 € vers le Livret A",
		on: true
	},
	{
		id: "r3",
		name: "Gros abonnement",
		when: "Abonnement supérieur à 20 €",
		action: "Demander confirmation",
		on: false
	}
];
var SUBS = [
	{
		id: "sub1",
		name: "Netflix",
		price: 15.9,
		renews: "12 du mois",
		category: "Abonnements",
		status: "actif"
	},
	{
		id: "sub2",
		name: "Spotify",
		price: 11,
		renews: "9 du mois",
		category: "Abonnements",
		status: "actif"
	},
	{
		id: "sub3",
		name: "Salle de sport",
		price: 39.9,
		renews: "4 du mois",
		category: "Abonnements",
		status: "actif"
	},
	{
		id: "sub4",
		name: "iCloud",
		price: 2.99,
		renews: "21 du mois",
		category: "Abonnements",
		status: "actif"
	},
	{
		id: "sub5",
		name: "Suite créative",
		price: 23,
		renews: "18 du mois",
		category: "Outils",
		status: "essai",
		trialEnd: "2026-11-30"
	}
];
var PLANS = [
	{
		id: "p1",
		name: "Épargne auto",
		detail: "200 € virés vers le Livret A le 30",
		amount: 200,
		status: "actif"
	},
	{
		id: "p2",
		name: "Lissage des charges",
		detail: "Réserve de 150 € pour EDF et impôts",
		amount: 150,
		status: "actif"
	},
	{
		id: "p3",
		name: "Remboursement anticipé",
		detail: "100 € de plus sur le crédit auto",
		amount: 100,
		status: "pause"
	}
];
var INVOICES = [
	{
		id: "i1",
		number: "FAC-1042",
		client: "Atelier Nord",
		amount: 2400,
		status: "payée",
		date: "2026-11-17"
	},
	{
		id: "i2",
		number: "FAC-1038",
		client: "Studio Lina",
		amount: 1800,
		status: "en attente",
		date: "2026-11-12"
	},
	{
		id: "i3",
		number: "FAC-1031",
		client: "Maison Brume",
		amount: 960,
		status: "payée",
		date: "2026-11-04"
	}
];
var NOTIFS = [
	{
		id: "n1",
		title: "EDF a augmenté de 18 %",
		detail: "Par rapport à votre moyenne des six derniers mois.",
		time: "il y a 2 h",
		href: "/analytique",
		read: false
	},
	{
		id: "n2",
		title: "2 abonnements se renouvellent",
		detail: "iCloud le 21, épargne auto le 30.",
		time: "hier",
		href: "/abonnements",
		read: false
	},
	{
		id: "n3",
		title: "FAC-1038 encore en attente",
		detail: "Studio Lina · 1 800 € depuis le 12 novembre.",
		time: "il y a 3 j",
		href: "/business",
		read: false
	}
];
var LOGOS = [
	"AN",
	"SL",
	"MB",
	"N",
	"S",
	"FV",
	"QB",
	"EDF"
];
var HELP = [
	{
		id: "h1",
		title: "Ajouter une opération",
		body: "Depuis n’importe quel écran, « Nouvelle opération » ouvre le journal. Choisissez dépense, revenu ou virement, puis le compte. Le solde du compte bouge tout de suite."
	},
	{
		id: "h2",
		title: "Lire le solde projeté",
		body: "Le planner additionne ce qui est déjà passé et les échéances restantes du mois. Le salaire du 28 et l’épargne auto du 30 sont encore devant vous."
	},
	{
		id: "h3",
		title: "Relier un compte",
		body: "Paramètres → Gérer les comptes. Ajoutez un courant, un livret ou un compte pro. Le solde de départ se corrige sans réécrire l’historique."
	},
	{
		id: "h4",
		title: "Contrôle de fin de mois",
		body: "Le centre « Contrôle mensuel » passe en revue les anomalies, le budget, puis prépare le rapport. Rien n’est figé tant que vous ne terminez pas."
	},
	{
		id: "h5",
		title: "Passer en mode professionnel",
		body: "Le sélecteur Personnel / Pro / Les deux, en haut, filtre le journal et le tableau de bord. La page Business reste la vue factures et trésorerie."
	}
];
var SESSIONS = [{
	id: "se1",
	device: "Chrome · Paris",
	when: "en ce moment",
	current: true
}, {
	id: "se2",
	device: "Safari · Lyon",
	when: "il y a 3 jours",
	current: false
}];
var BUDGETS = {
	Logement: 1400,
	Alimentation: 500,
	Transport: 250,
	Abonnements: 120,
	Énergie: 90,
	Santé: 80,
	Loisirs: 250,
	Charges: 1200,
	Autre: 200
};
var SNAP = {
	both: {
		balance: 18420,
		delta: 4.2,
		health: 82
	},
	perso: {
		balance: 12920,
		delta: 3.1,
		health: 76
	},
	pro: {
		balance: 5500,
		delta: 8.4,
		health: 88
	}
};
function inScope(scope, mode) {
	return mode === "both" || mode === scope;
}
var seedSettings = {
	notifEmail: true,
	notifPush: false,
	notifWeekly: true,
	advice: true
};
var seedPro = {
	tradeName: "Camille Morel Studio",
	siret: "849 302 118 00024",
	vat: "FR 12 849302118",
	address: "14 rue des Archives, 75004 Paris",
	prefix: "FAC-",
	delay: "30",
	mention: "TVA non applicable, art. 293 B du CGI.",
	remind: true,
	remindLate: true
};
var useFreev = create()(persist((set, get) => ({
	theme: "ink",
	mode: "both",
	txs: SEED_TX,
	accounts: ACCOUNTS,
	goals: GOALS,
	debts: DEBTS,
	rules: RULES,
	subs: SUBS,
	plans: PLANS,
	invoices: INVOICES,
	budgets: BUDGETS,
	settings: seedSettings,
	pro: seedPro,
	notifs: NOTIFS,
	profile: {
		name: "Camille Morel",
		email: "camille@freev.app",
		defaultMode: "both"
	},
	activeAccountId: "courant",
	logoPick: "FV",
	closedSessions: [],
	twoFa: false,
	duplicated: [],
	dialog: null,
	searchOpen: false,
	notifOpen: false,
	userOpen: false,
	navOpen: false,
	setTheme: (theme) => set({ theme }),
	setMode: (mode) => set({ mode }),
	open: (dialog) => set({ dialog }),
	setSearch: (searchOpen) => set({
		searchOpen,
		notifOpen: false,
		userOpen: false
	}),
	setNotif: (notifOpen) => set({
		notifOpen,
		searchOpen: false,
		userOpen: false
	}),
	setUser: (userOpen) => set({
		userOpen,
		searchOpen: false,
		notifOpen: false
	}),
	setNav: (navOpen) => set({ navOpen }),
	setLogo: (logoPick) => set({ logoPick }),
	addTx: (tx) => set((s) => {
		const id = uid("tx");
		return {
			txs: [{
				...tx,
				id
			}, ...s.txs],
			accounts: s.accounts.map((a) => {
				if (tx.kind === "transfer") return a;
				if (a.id !== tx.accountId || tx.pending) return a;
				return {
					...a,
					balance: Math.round((a.balance + tx.amount) * 100) / 100
				};
			}),
			dialog: null
		};
	}),
	updateTx: (id, patch) => set((s) => ({ txs: s.txs.map((t) => t.id === id ? {
		...t,
		...patch
	} : t) })),
	removeTx: (id) => set((s) => ({ txs: s.txs.filter((t) => t.id !== id) })),
	addAccount: (a) => set((s) => ({ accounts: [...s.accounts, {
		...a,
		id: uid("acc")
	}] })),
	patchAccount: (id, patch) => set((s) => ({ accounts: s.accounts.map((a) => a.id === id ? {
		...a,
		...patch
	} : a) })),
	removeAccount: (id) => set((s) => ({
		accounts: s.accounts.filter((a) => a.id !== id),
		activeAccountId: s.activeAccountId === id ? s.accounts.find((a) => a.id !== id)?.id ?? "" : s.activeAccountId
	})),
	setActiveAccount: (activeAccountId) => set({
		activeAccountId,
		dialog: null
	}),
	transfer: (from, to, amount, note, date) => set((s) => {
		const accounts = s.accounts.map((a) => {
			if (a.id === from) return {
				...a,
				balance: Math.round((a.balance - amount) * 100) / 100
			};
			if (a.id === to) return {
				...a,
				balance: Math.round((a.balance + amount) * 100) / 100
			};
			return a;
		});
		const src = s.accounts.find((a) => a.id === from);
		const dst = s.accounts.find((a) => a.id === to);
		return {
			accounts,
			txs: [{
				id: uid("tx"),
				date,
				label: note || `Virement → ${dst?.name ?? "compte"}`,
				category: "Virement",
				accountId: from,
				toAccountId: to,
				amount,
				scope: src?.scope ?? "perso",
				kind: "transfer",
				recurring: false,
				pending: false
			}, ...s.txs],
			dialog: null
		};
	}),
	saveGoal: (g) => set((s) => ({
		goals: s.goals.some((x) => x.id === g.id) ? s.goals.map((x) => x.id === g.id ? g : x) : [g, ...s.goals],
		dialog: null
	})),
	removeGoal: (id) => set((s) => ({ goals: s.goals.filter((g) => g.id !== id) })),
	saveDebt: (d) => set((s) => ({
		debts: s.debts.some((x) => x.id === d.id) ? s.debts.map((x) => x.id === d.id ? d : x) : [d, ...s.debts],
		dialog: null
	})),
	payDebt: (id) => set((s) => ({ debts: s.debts.map((d) => d.id === id ? {
		...d,
		remaining: Math.max(0, Math.round((d.remaining - d.monthly) * 100) / 100)
	} : d) })),
	toggleRule: (id) => set((s) => ({ rules: s.rules.map((r) => r.id === id ? {
		...r,
		on: !r.on
	} : r) })),
	addRule: (r) => set((s) => ({
		rules: [{
			...r,
			id: uid("rule")
		}, ...s.rules],
		dialog: null
	})),
	setSubStatus: (id, status) => set((s) => ({ subs: s.subs.map((x) => x.id === id ? {
		...x,
		status
	} : x) })),
	addSub: (sub) => set((s) => ({
		subs: [{
			...sub,
			id: uid("sub")
		}, ...s.subs],
		dialog: null
	})),
	togglePlan: (id) => set((s) => ({ plans: s.plans.map((p) => p.id === id ? {
		...p,
		status: p.status === "actif" ? "pause" : "actif"
	} : p) })),
	addPlan: (p) => set((s) => ({ plans: [{
		...p,
		id: uid("plan")
	}, ...s.plans] })),
	setBudgets: (budgets) => set({
		budgets,
		dialog: null
	}),
	patchSettings: (p) => set((s) => ({ settings: {
		...s.settings,
		...p
	} })),
	patchPro: (p) => set((s) => ({ pro: {
		...s.pro,
		...p
	} })),
	patchProfile: (p) => set((s) => ({ profile: {
		...s.profile,
		...p
	} })),
	markNotifs: () => set((s) => ({ notifs: s.notifs.map((n) => ({
		...n,
		read: true
	})) })),
	markInvoice: (id) => set((s) => {
		const inv = s.invoices.find((i) => i.id === id);
		if (!inv || inv.status === "payée") return s;
		const tx = {
			id: uid("tx"),
			date: TODAY,
			label: inv.client,
			category: "Prestation",
			accountId: "pro",
			amount: inv.amount,
			scope: "pro",
			kind: "income",
			recurring: false,
			pending: false
		};
		return {
			invoices: s.invoices.map((i) => i.id === id ? {
				...i,
				status: "payée"
			} : i),
			txs: [tx, ...s.txs],
			accounts: s.accounts.map((a) => a.id === "pro" ? {
				...a,
				balance: Math.round((a.balance + inv.amount) * 100) / 100
			} : a)
		};
	}),
	addInvoice: (i) => set((s) => {
		const n = 1043 + s.invoices.length;
		return {
			invoices: [{
				...i,
				id: uid("inv"),
				number: `${s.pro.prefix}${n}`
			}, ...s.invoices],
			dialog: null
		};
	}),
	remind: (id) => {
		const inv = get().invoices.find((i) => i.id === id);
		return inv ? `Relance envoyée à ${inv.client}` : "Relance envoyée";
	},
	closeSession: (id) => set((s) => ({ closedSessions: [...s.closedSessions, id] })),
	setTwoFa: (twoFa) => set({ twoFa }),
	markDuplicated: (month) => set((s) => ({
		duplicated: [.../* @__PURE__ */ new Set([...s.duplicated, month])],
		dialog: null
	})),
	wipe: () => set({
		txs: [],
		goals: [],
		debts: [],
		subs: [],
		rules: [],
		invoices: [],
		dialog: null
	})
}), {
	name: "freev",
	skipHydration: true,
	partialize: (s) => ({
		theme: s.theme,
		mode: s.mode,
		txs: s.txs,
		accounts: s.accounts,
		goals: s.goals,
		debts: s.debts,
		rules: s.rules,
		subs: s.subs,
		plans: s.plans,
		invoices: s.invoices,
		budgets: s.budgets,
		settings: s.settings,
		pro: s.pro,
		notifs: s.notifs,
		profile: s.profile,
		activeAccountId: s.activeAccountId,
		logoPick: s.logoPick,
		closedSessions: s.closedSessions,
		twoFa: s.twoFa,
		duplicated: s.duplicated
	})
}));
function Overlays() {
	const dialog = useFreev((s) => s.dialog);
	if (!dialog) return null;
	if (dialog.name === "tx") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxDialog, {});
	if (dialog.name === "duplicate") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DuplicateDialog, {});
	if (dialog.name === "budget") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetDialog, {});
	if (dialog.name === "opening") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpeningDialog, {});
	if (dialog.name === "transfer") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferDialog, {});
	if (dialog.name === "goal") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalDialog, { id: dialog.id });
	if (dialog.name === "debt") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DebtDialog, { id: dialog.id });
	if (dialog.name === "accounts") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountsDialog, {});
	if (dialog.name === "pick-account") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickAccountDialog, {});
	if (dialog.name === "recurrence") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecurrenceDialog, { id: dialog.id });
	if (dialog.name === "trial") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrialDialog, {});
	if (dialog.name === "invoice") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceDialog, {});
	if (dialog.name === "wipe") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WipeDialog, {});
	return null;
}
function Modal({ title, lede, children }) {
	const open = useFreev((s) => s.open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end sm:items-center sm:justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fermer",
			className: "veil absolute inset-0",
			onClick: () => open(null)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "relative max-h-screen w-full overflow-y-auto border border-rule bg-card p-5 shadow-lift sm:max-w-lg sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-copper",
					children: "Journal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-serif text-3xl",
					children: title
				}),
				lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-mist",
					children: lede
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children
				})
			]
		})]
	});
}
function KindSwitch({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex border border-rule",
		children: [
			{
				id: "expense",
				label: "Dépense"
			},
			{
				id: "income",
				label: "Revenu"
			},
			{
				id: "transfer",
				label: "Virement"
			}
		].map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(o.id),
			className: value === o.id ? "h-10 flex-1 bg-copper text-xs uppercase tracking-widest text-copper-ink" : "h-10 flex-1 text-xs uppercase tracking-widest text-mist",
			children: o.label
		}, o.id))
	});
}
function TxDialog() {
	const dialog = useFreev((s) => s.dialog);
	const accounts = useFreev((s) => s.accounts);
	const addTx = useFreev((s) => s.addTx);
	const open = useFreev((s) => s.open);
	const date0 = dialog && dialog.name === "tx" && dialog.date ? dialog.date : TODAY;
	const [kind, setKind] = (0, import_react.useState)("expense");
	const [label, setLabel] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(date0);
	const [category, setCategory] = (0, import_react.useState)("Alimentation");
	const [accountId, setAccountId] = (0, import_react.useState)(accounts[0]?.id ?? "courant");
	const [toId, setToId] = (0, import_react.useState)(accounts[1]?.id ?? accounts[0]?.id ?? "");
	const [scope, setScope] = (0, import_react.useState)("perso");
	const [recurring, setRecurring] = (0, import_react.useState)(false);
	const [logo, setLogo] = (0, import_react.useState)("FV");
	const [picking, setPicking] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	function save() {
		const n = Number(amount.replace(",", "."));
		if (!label.trim() || !Number.isFinite(n) || n <= 0) {
			setError("Indiquez un libellé et un montant supérieur à zéro.");
			return;
		}
		if (kind === "transfer") {
			if (accountId === toId) {
				setError("Choisissez deux comptes différents.");
				return;
			}
			useFreev.getState().transfer(accountId, toId, n, label, date);
			toast("Virement enregistré");
			return;
		}
		addTx({
			date,
			label: label.trim(),
			category,
			accountId,
			amount: kind === "expense" ? -n : n,
			scope,
			kind,
			recurring,
			pending: false,
			logo
		});
		toast("Opération ajoutée au journal");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Nouvelle opération",
		lede: "Dépense, revenu, ou mouvement entre vos comptes.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindSwitch, {
					value: kind,
					onChange: setKind
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Libellé",
					value: label,
					onChange: (e) => setLabel(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Montant",
					inputMode: "decimal",
					value: amount,
					onChange: (e) => setAmount(e.target.value),
					placeholder: "0,00"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value)
				}),
				kind !== "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Catégorie",
					value: category,
					onChange: (e) => setCategory(e.target.value),
					children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: kind === "transfer" ? "Depuis" : "Compte",
					value: accountId,
					onChange: (e) => setAccountId(e.target.value),
					children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				}),
				kind === "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Vers",
					value: toId,
					onChange: (e) => setToId(e.target.value),
					children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					label: "Périmètre",
					value: scope,
					onChange: (e) => setScope(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "perso",
						children: "Personnel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "pro",
						children: "Professionnel"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-rule py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Récurrence mensuelle"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: recurring,
						onChange: setRecurring,
						label: "Récurrence"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm",
						children: ["Signe ", logo]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						onClick: () => setPicking((v) => !v),
						children: "Choisir un logo"
					})]
				}),
				picking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					children: LOGOS.map((mark) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setLogo(mark);
							setPicking(false);
						},
						className: mark === logo ? "h-12 border border-copper font-serif text-copper" : "h-12 border border-rule font-serif",
						children: mark
					}, mark))
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "primary",
						onClick: save,
						children: "Enregistrer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function DuplicateDialog() {
	const mark = useFreev((s) => s.markDuplicated);
	const open = useFreev((s) => s.open);
	const [month, setMonth] = (0, import_react.useState)("2026-12");
	const [income, setIncome] = (0, import_react.useState)(true);
	const [expense, setExpense] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Dupliquer le mois",
		lede: "Reprend les échéances connues sur le mois choisi.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mois cible",
					type: "month",
					value: month,
					onChange: (e) => setMonth(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Reprendre les revenus"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: income,
						onChange: setIncome,
						label: "Revenus"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Reprendre les dépenses"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: expense,
						onChange: setExpense,
						label: "Dépenses"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-rule border-y border-rule text-sm",
					children: SCHEDULE.filter((s) => s.amount > 0 ? income : expense).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							s.label,
							" · jour ",
							s.day
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								s.amount > 0 ? "+" : "−",
								Math.abs(s.amount),
								" €"
							]
						})]
					}, s.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							mark(month);
							toast(`Échéances posées sur ${month}`);
						},
						children: "Dupliquer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function BudgetDialog() {
	const budgets = useFreev((s) => s.budgets);
	const setBudgets = useFreev((s) => s.setBudgets);
	const open = useFreev((s) => s.open);
	const [draft, setDraft] = (0, import_react.useState)(budgets);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Budget du mois",
		lede: "Plafonds par catégorie. Le contrôle mensuel s’y réfère.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [Object.entries(draft).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: k,
				inputMode: "decimal",
				value: String(v),
				onChange: (e) => setDraft({
					...draft,
					[k]: Number(e.target.value.replace(",", ".")) || 0
				})
			}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => {
						setBudgets(draft);
						toast("Budget enregistré");
					},
					children: "Enregistrer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => open(null),
					children: "Annuler"
				})]
			})]
		})
	});
}
function OpeningDialog() {
	const accounts = useFreev((s) => s.accounts);
	const patch = useFreev((s) => s.patchAccount);
	const open = useFreev((s) => s.open);
	const [id, setId] = (0, import_react.useState)(accounts[0]?.id ?? "");
	const current = accounts.find((a) => a.id === id);
	const [amount, setAmount] = (0, import_react.useState)(String(current?.balance ?? 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Solde de départ",
		lede: "Corrige le solde sans réécrire les opérations déjà passées.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Compte",
					value: id,
					onChange: (e) => {
						setId(e.target.value);
						const acc = accounts.find((a) => a.id === e.target.value);
						setAmount(String(acc?.balance ?? 0));
					},
					children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Solde",
					inputMode: "decimal",
					value: amount,
					onChange: (e) => setAmount(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							const n = Number(amount.replace(",", "."));
							if (!Number.isFinite(n)) return;
							patch(id, { balance: n });
							open(null);
							toast("Solde mis à jour");
						},
						children: "Mettre à jour"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function TransferDialog() {
	const accounts = useFreev((s) => s.accounts);
	const open = useFreev((s) => s.open);
	const [from, setFrom] = (0, import_react.useState)(accounts[0]?.id ?? "");
	const [to, setTo] = (0, import_react.useState)(accounts[1]?.id ?? "");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(TODAY);
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Entre comptes",
		lede: "Le solde global ne change pas. Seule la répartition bouge.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Depuis",
					value: from,
					onChange: (e) => setFrom(e.target.value),
					children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Vers",
					value: to,
					onChange: (e) => setTo(e.target.value),
					children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Montant",
					value: amount,
					onChange: (e) => setAmount(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note",
					value: note,
					onChange: (e) => setNote(e.target.value)
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							const n = Number(amount.replace(",", "."));
							if (!n || from === to) {
								setError("Montant valide, et deux comptes distincts.");
								return;
							}
							useFreev.getState().transfer(from, to, n, note, date);
							toast("Virement passé");
						},
						children: "Virer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function GoalDialog({ id }) {
	const goals = useFreev((s) => s.goals);
	const save = useFreev((s) => s.saveGoal);
	const open = useFreev((s) => s.open);
	const accounts = useFreev((s) => s.accounts);
	const existing = goals.find((g) => g.id === id);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [current, setCurrent] = (0, import_react.useState)(String(existing?.current ?? 0));
	const [target, setTarget] = (0, import_react.useState)(String(existing?.target ?? 1e3));
	const [due, setDue] = (0, import_react.useState)(existing?.due ?? "2027-06-01");
	const [accountId, setAccountId] = (0, import_react.useState)(existing?.accountId ?? "livret");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: existing ? "Ajuster l’objectif" : "Nouvel objectif",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nom",
					value: name,
					onChange: (e) => setName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Déjà mis de côté",
					value: current,
					onChange: (e) => setCurrent(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Cible",
					value: target,
					onChange: (e) => setTarget(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Échéance",
					type: "date",
					value: due,
					onChange: (e) => setDue(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Compte",
					value: accountId,
					onChange: (e) => setAccountId(e.target.value),
					children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: a.id,
						children: a.name
					}, a.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							if (!name.trim()) return;
							save({
								id: existing?.id ?? uid("goal"),
								name: name.trim(),
								current: Number(current.replace(",", ".")) || 0,
								target: Number(target.replace(",", ".")) || 0,
								due,
								accountId
							});
							toast("Objectif enregistré");
						},
						children: "Enregistrer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function DebtDialog({ id }) {
	const debts = useFreev((s) => s.debts);
	const save = useFreev((s) => s.saveDebt);
	const open = useFreev((s) => s.open);
	const existing = debts.find((d) => d.id === id);
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [remaining, setRemaining] = (0, import_react.useState)(String(existing?.remaining ?? ""));
	const [monthly, setMonthly] = (0, import_react.useState)(String(existing?.monthly ?? ""));
	const [rate, setRate] = (0, import_react.useState)(String(existing?.rate ?? 0));
	const [end, setEnd] = (0, import_react.useState)(existing?.end ?? "2028-01-01");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: existing ? "Modifier la dette" : "Nouvelle dette",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nom",
					value: name,
					onChange: (e) => setName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Reste à payer",
					value: remaining,
					onChange: (e) => setRemaining(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mensualité",
					value: monthly,
					onChange: (e) => setMonthly(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Taux (%)",
					value: rate,
					onChange: (e) => setRate(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fin",
					type: "date",
					value: end,
					onChange: (e) => setEnd(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							if (!name.trim()) return;
							save({
								id: existing?.id ?? uid("debt"),
								name: name.trim(),
								remaining: Number(remaining.replace(",", ".")) || 0,
								monthly: Number(monthly.replace(",", ".")) || 0,
								rate: Number(rate.replace(",", ".")) || 0,
								end
							});
							toast("Dette enregistrée");
						},
						children: "Enregistrer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function AccountsDialog() {
	const accounts = useFreev((s) => s.accounts);
	const add = useFreev((s) => s.addAccount);
	const remove = useFreev((s) => s.removeAccount);
	const open = useFreev((s) => s.open);
	const [name, setName] = (0, import_react.useState)("");
	const [bank, setBank] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("courant");
	const [scope, setScope] = (0, import_react.useState)("perso");
	const [balance, setBalance] = (0, import_react.useState)("0");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		title: "Gestion des comptes",
		lede: "Ajoutez un compte ou retirez-en un. Le solde de départ se règle à part.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-rule border-y border-rule",
			children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm",
					children: a.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-mist",
					children: [
						a.bank,
						" · ",
						a.kind
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => remove(a.id),
					disabled: accounts.length < 2,
					children: "Retirer"
				})]
			}, a.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nom",
					value: name,
					onChange: (e) => setName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Banque",
					value: bank,
					onChange: (e) => setBank(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					label: "Type",
					value: kind,
					onChange: (e) => setKind(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "courant",
							children: "Courant"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "epargne",
							children: "Épargne"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "pro",
							children: "Professionnel"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					label: "Périmètre",
					value: scope,
					onChange: (e) => setScope(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "perso",
						children: "Personnel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "pro",
						children: "Professionnel"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Solde initial",
					value: balance,
					onChange: (e) => setBalance(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "primary",
							onClick: () => {
								if (!name.trim()) return;
								add({
									name: name.trim(),
									bank: bank.trim() || "Banque",
									balance: Number(balance.replace(",", ".")) || 0,
									scope,
									kind
								});
								setName("");
								toast("Compte ajouté");
							},
							children: "Ajouter"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => open(null),
							children: "Fermer"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => open({ name: "opening" }),
							children: "Solde de départ"
						})
					]
				})
			]
		})]
	});
}
function PickAccountDialog() {
	const accounts = useFreev((s) => s.accounts);
	const active = useFreev((s) => s.activeAccountId);
	const setActive = useFreev((s) => s.setActiveAccount);
	const [id, setId] = (0, import_react.useState)(active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Choisir un compte",
		lede: "Le compte actif sert de défaut pour les nouvelles opérations.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setId(a.id),
				className: id === a.id ? "flex w-full items-center justify-between border border-copper px-3 py-3 text-left" : "flex w-full items-center justify-between border border-rule px-3 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm",
					children: a.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-mist",
					children: a.bank
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs uppercase tracking-widest",
					children: a.scope
				})]
			}, a.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				className: "mt-3",
				onClick: () => setActive(id),
				children: "Utiliser ce compte"
			})]
		})
	});
}
function RecurrenceDialog({ id }) {
	const txs = useFreev((s) => s.txs);
	const update = useFreev((s) => s.updateTx);
	const add = useFreev((s) => s.addTx);
	const open = useFreev((s) => s.open);
	const existing = txs.find((t) => t.id === id);
	const [label, setLabel] = (0, import_react.useState)(existing?.label ?? "");
	const [amount, setAmount] = (0, import_react.useState)(existing ? String(Math.abs(existing.amount)) : "");
	const [category, setCategory] = (0, import_react.useState)(existing?.category ?? "Abonnements");
	const [day, setDay] = (0, import_react.useState)(existing ? String(Number(existing.date.slice(8, 10))) : "1");
	const [scope, setScope] = (0, import_react.useState)(existing?.scope ?? "perso");
	const [income, setIncome] = (0, import_react.useState)(existing ? existing.amount > 0 : false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: existing ? "Modifier la récurrence" : "Nouvelle récurrence",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Libellé",
					value: label,
					onChange: (e) => setLabel(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Montant",
					value: amount,
					onChange: (e) => setAmount(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Jour du mois",
					value: day,
					onChange: (e) => setDay(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "Catégorie",
					value: category,
					onChange: (e) => setCategory(e.target.value),
					children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					label: "Périmètre",
					value: scope,
					onChange: (e) => setScope(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "perso",
						children: "Personnel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "pro",
						children: "Professionnel"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "C’est un revenu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: income,
						onChange: setIncome,
						label: "Revenu"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							const n = Number(amount.replace(",", "."));
							if (!label.trim() || !n) return;
							const signed = income ? n : -n;
							const d = Math.min(28, Math.max(1, Number(day) || 1));
							const date = `2026-11-${String(d).padStart(2, "0")}`;
							if (existing) {
								update(existing.id, {
									label: label.trim(),
									amount: signed,
									category,
									scope,
									date,
									recurring: true,
									kind: income ? "income" : "expense"
								});
								open(null);
							} else add({
								label: label.trim(),
								amount: signed,
								category,
								scope,
								date,
								accountId: scope === "pro" ? "pro" : "courant",
								kind: income ? "income" : "expense",
								recurring: true,
								pending: true
							});
							toast("Récurrence enregistrée");
						},
						children: "Enregistrer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function TrialDialog() {
	const add = useFreev((s) => s.addSub);
	const open = useFreev((s) => s.open);
	const [name, setName] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [trialEnd, setTrialEnd] = (0, import_react.useState)("2026-12-19");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Nouvel essai",
		lede: "On vous prévient avant la fin de la période gratuite.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Service",
					value: name,
					onChange: (e) => setName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Prix ensuite",
					value: price,
					onChange: (e) => setPrice(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fin de l’essai",
					type: "date",
					value: trialEnd,
					onChange: (e) => setTrialEnd(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							if (!name.trim()) return;
							add({
								name: name.trim(),
								price: Number(price.replace(",", ".")) || 0,
								renews: "après l’essai",
								category: "Essai",
								status: "essai",
								trialEnd
							});
							toast("Essai ajouté");
						},
						children: "Ajouter"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function InvoiceDialog() {
	const add = useFreev((s) => s.addInvoice);
	const open = useFreev((s) => s.open);
	const [client, setClient] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(TODAY);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Nouvelle facture",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Client",
					value: client,
					onChange: (e) => setClient(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Montant",
					value: amount,
					onChange: (e) => setAmount(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "primary",
						onClick: () => {
							const n = Number(amount.replace(",", "."));
							if (!client.trim() || !n) return;
							add({
								client: client.trim(),
								amount: n,
								status: "en attente",
								date
							});
							toast("Facture créée");
						},
						children: "Créer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => open(null),
						children: "Annuler"
					})]
				})
			]
		})
	});
}
function WipeDialog() {
	const wipe = useFreev((s) => s.wipe);
	const open = useFreev((s) => s.open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		title: "Supprimer mes données",
		lede: "Le journal, les objectifs, les dettes et les factures de cet appareil seront vidés. Les comptes restent.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => {
					wipe();
					toast("Données locales effacées");
				},
				children: "Effacer"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => open(null),
				children: "Annuler"
			})]
		})
	});
}
var GROUPS = [
	{
		label: null,
		items: [
			{
				to: "/",
				label: "Tableau de bord",
				icon: LayoutDashboard
			},
			{
				to: "/analytique",
				label: "Analytique",
				icon: ChartLine
			},
			{
				to: "/business",
				label: "Business",
				icon: Briefcase
			}
		]
	},
	{
		label: "Opérations",
		items: [
			{
				to: "/transactions",
				label: "Transactions",
				icon: ArrowLeftRight
			},
			{
				to: "/recurrences",
				label: "Récurrences",
				icon: Repeat
			},
			{
				to: "/historique",
				label: "Historique",
				icon: History
			}
		]
	},
	{
		label: "Planification",
		items: [
			{
				to: "/planner",
				label: "Planner",
				icon: CalendarRange
			},
			{
				to: "/smart",
				label: "Smart",
				icon: Sparkles
			},
			{
				to: "/epargne",
				label: "Épargne",
				icon: PiggyBank
			},
			{
				to: "/dettes",
				label: "Dettes",
				icon: Landmark
			}
		]
	},
	{
		label: null,
		items: [{
			to: "/parametres",
			label: "Paramètres",
			icon: Settings
		}]
	},
	{
		label: "Centre",
		items: [
			{
				to: "/controle",
				label: "Contrôle mensuel",
				icon: ClipboardCheck
			},
			{
				to: "/regles",
				label: "Règles",
				icon: Scale
			},
			{
				to: "/abonnements",
				label: "Abonnements",
				icon: CreditCard
			},
			{
				to: "/patrimoine",
				label: "Patrimoine",
				icon: Gem
			},
			{
				to: "/securite",
				label: "Sécurité",
				icon: Shield
			}
		]
	}
];
var MODES = [
	{
		id: "perso",
		label: "Personnel"
	},
	{
		id: "pro",
		label: "Pro"
	},
	{
		id: "both",
		label: "Les deux"
	}
];
function isActive(path, to) {
	return to === "/" ? path === "/" : path === to;
}
function Rail({ onNavigate }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const theme = useFreev((s) => s.theme);
	const setTheme = useFreev((s) => s.setTheme);
	const profile = useFreev((s) => s.profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-rule px-5 py-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					onClick: onNavigate,
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-serif text-2xl tracking-tight",
						children: "FREEV"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs uppercase tracking-widest text-mist",
						children: "Livre de comptes"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex-1 overflow-y-auto px-3 py-4",
				"aria-label": "Navigation",
				children: GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [group.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 pb-2 text-xs uppercase tracking-widest text-mist",
						children: group.label
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-0.5",
						children: group.items.map((item) => {
							const Icon = item.icon;
							const on = isActive(path, item.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								onClick: onNavigate,
								className: cn("flex items-center gap-3 border-l-2 px-2 py-2 text-sm", on ? "border-copper bg-card-2 text-ink" : "border-transparent text-mist hover:text-ink"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4 shrink-0",
									strokeWidth: 1.5,
									"aria-hidden": true
								}), item.label]
							}) }, item.to);
						})
					})]
				}, group.label ?? group.items[0].to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t border-rule p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTheme(theme === "paper" ? "ink" : "paper"),
						className: "h-9 flex-1 border border-rule text-xs uppercase tracking-widest",
						children: theme === "paper" ? "Clair" : theme === "ink" ? "Sombre" : "Système"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/aide",
						onClick: onNavigate,
						className: "inline-flex size-9 items-center justify-center border border-rule",
						"aria-label": "Aide",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
							className: "size-4",
							strokeWidth: 1.5
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/compte",
					onClick: onNavigate,
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex size-9 items-center justify-center border border-copper font-serif text-copper",
						children: profile.name.slice(0, 1)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm",
							children: profile.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs text-mist",
							children: profile.email
						})]
					})]
				})]
			})
		]
	});
}
function Shell({ children }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const mode = useFreev((s) => s.mode);
	const setMode = useFreev((s) => s.setMode);
	const navOpen = useFreev((s) => s.navOpen);
	const setNav = useFreev((s) => s.setNav);
	const setSearch = useFreev((s) => s.setSearch);
	const setNotif = useFreev((s) => s.setNotif);
	const setUser = useFreev((s) => s.setUser);
	const notifOpen = useFreev((s) => s.notifOpen);
	const userOpen = useFreev((s) => s.userOpen);
	const notifs = useFreev((s) => s.notifs);
	const profile = useFreev((s) => s.profile);
	const unread = notifs.filter((n) => !n.read).length;
	const theme = useFreev((s) => s.theme);
	(0, import_react.useEffect)(() => {
		useFreev.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			const choice = useFreev.getState().theme;
			const dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
			document.documentElement.dataset.theme = choice === "system" ? dark ? "ink" : "paper" : choice;
		};
		apply();
		const mq = window.matchMedia("(prefers-color-scheme: dark)");
		mq.addEventListener("change", apply);
		const unsub = useFreev.subscribe(apply);
		return () => {
			mq.removeEventListener("change", apply);
			unsub();
		};
	}, [theme]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
			if (e.key === "/" || (e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				setSearch(true);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [setSearch]);
	const title = GROUPS.flatMap((g) => g.items).find((i) => isActive(path, i.to))?.label ?? "FREEV";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh overflow-hidden bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-60 shrink-0 border-r border-rule lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {})
			}),
			navOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Fermer le menu",
					className: "veil absolute inset-0",
					onClick: () => setNav(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "absolute inset-y-0 left-0 w-72 border-r border-rule shadow-lift",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, { onNavigate: () => setNav(false) })
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex h-14 shrink-0 items-center gap-3 border-b border-rule px-3 md:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-10 items-center justify-center lg:hidden",
							"aria-label": "Ouvrir le menu",
							onClick: () => setNav(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: "size-5",
								strokeWidth: 1.5
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden min-w-0 truncate text-xs uppercase tracking-widest text-mist sm:block",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex items-center gap-2 md:gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden items-center gap-1 md:flex",
									role: "tablist",
									"aria-label": "Périmètre",
									children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "tab",
										"aria-selected": mode === m.id,
										onClick: () => setMode(m.id),
										className: cn("h-9 px-2 text-xs uppercase tracking-widest", mode === m.id ? "border-b border-copper text-ink" : "text-mist hover:text-ink"),
										children: m.label
									}, m.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "md:hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Périmètre"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: mode,
										onChange: (e) => setMode(e.target.value),
										className: "h-9 border border-rule bg-transparent px-2 text-xs uppercase tracking-widest",
										children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: m.id,
											children: m.label
										}, m.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Rechercher",
									className: "inline-flex size-10 items-center justify-center",
									onClick: () => setSearch(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										className: "size-4",
										strokeWidth: 1.5
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-label": "Notifications",
										className: "relative inline-flex size-10 items-center justify-center",
										onClick: () => setNotif(!notifOpen),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
											className: "size-4",
											strokeWidth: 1.5
										}), unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-1.5 bg-copper" }) : null]
									}), notifOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotifPanel, {}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": "Compte",
										className: "inline-flex size-9 items-center justify-center border border-rule font-serif",
										onClick: () => setUser(!userOpen),
										children: profile.name.slice(0, 1)
									}), userOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPanel, {}) : null]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8 md:py-8",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlays, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchOverlay, {})
		]
	});
}
function NotifPanel() {
	const notifs = useFreev((s) => s.notifs);
	const mark = useFreev((s) => s.markNotifs);
	const setNotif = useFreev((s) => s.setNotif);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute right-0 z-30 mt-2 w-80 border border-rule bg-card p-4 shadow-lift",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-mist",
				children: "Notifications"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-xs uppercase tracking-widest text-copper",
				onClick: mark,
				children: "Tout lire"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-rule",
			children: notifs.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: n.href,
				onClick: () => setNotif(false),
				className: "block py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-sm", !n.read && "text-ink"),
						children: n.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-mist",
						children: n.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs uppercase tracking-widest text-mist",
						children: n.time
					})
				]
			}) }, n.id))
		})]
	});
}
function UserPanel() {
	const setUser = useFreev((s) => s.setUser);
	const profile = useFreev((s) => s.profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute right-0 z-30 mt-2 w-56 border border-rule bg-card p-2 shadow-lift",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-2 py-2 text-xs text-mist",
			children: profile.email
		}), [
			{
				to: "/compte",
				label: "Mon compte"
			},
			{
				to: "/parametres",
				label: "Paramètres"
			},
			{
				to: "/securite",
				label: "Sécurité"
			},
			{
				to: "/connexion",
				label: "Déconnexion"
			}
		].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: l.to,
			onClick: () => setUser(false),
			className: "block px-2 py-2 text-sm hover:bg-card-2",
			children: l.label
		}, l.to))]
	});
}
function SearchOverlay() {
	const open = useFreev((s) => s.searchOpen);
	const setSearch = useFreev((s) => s.setSearch);
	const txs = useFreev((s) => s.txs);
	const [value, setValue] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) setValue("");
	}, [open]);
	if (!open) return null;
	const q = value.trim().toLowerCase();
	const pages = GROUPS.flatMap((g) => g.items).filter((i) => !q || i.label.toLowerCase().includes(q));
	const ops = txs.filter((t) => !q || `${t.label} ${t.category}`.toLowerCase().includes(q)).slice(0, 6);
	const help = HELP.filter((h) => !q || h.title.toLowerCase().includes(q));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fermer la recherche",
			className: "veil absolute inset-0",
			onClick: () => setSearch(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "Recherche",
			className: "relative mx-auto mt-16 w-full max-w-xl border border-rule bg-card p-5 shadow-lift",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b border-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-mist" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value,
						onChange: (e) => setValue(e.target.value),
						placeholder: "Page, opération, aide",
						className: "h-12 w-full bg-transparent text-lg outline-none placeholder:text-mist"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Fermer",
						onClick: () => setSearch(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						title: "Pages",
						children: pages.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: p.to,
							onClick: () => setSearch(false),
							className: "block py-2 text-sm",
							children: p.label
						}, p.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
						title: "Opérations",
						children: [ops.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-mist",
							children: "Aucune opération."
						}) : null, ops.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/transactions",
							onClick: () => setSearch(false),
							className: "block py-2 text-sm",
							children: t.label
						}, t.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						title: "Aide",
						children: help.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/aide",
							onClick: () => setSearch(false),
							className: "block py-2 text-sm",
							children: h.title
						}, h.id))
					})
				]
			})]
		})]
	});
}
function Group({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs uppercase tracking-widest text-mist",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1",
		children
	})] });
}
//#endregion
export { SESSIONS as a, TODAY as c, SERIES as i, inScope as l, HISTORY as n, SNAP as o, SCHEDULE as r, Shell as s, HELP as t, useFreev as u };
