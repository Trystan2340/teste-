//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-uawkLwxc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/abonnements",
			"/abonnements-recurrents",
			"/aide",
			"/analytique",
			"/budget-personnel",
			"/business",
			"/compte",
			"/conditions",
			"/confidentialite",
			"/configuration",
			"/connexion",
			"/controle",
			"/dettes",
			"/epargne",
			"/historique",
			"/inscription",
			"/parametres",
			"/parametres-pro",
			"/patrimoine",
			"/planner",
			"/rapport",
			"/recurrences",
			"/regles",
			"/scanner",
			"/securite",
			"/smart",
			"/suivi-depenses",
			"/transactions",
			"/tresorerie"
		],
		preloads: ["/assets/index-B-z-4P5g.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B-z-4P5g.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-bc_BIQHC.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/observe-wvyLEcq9.js"
		]
	},
	"/abonnements": {
		filePath: "/workspace/src/routes/abonnements.tsx",
		children: void 0,
		preloads: [
			"/assets/abonnements-tUaIe6-w.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/abonnements-recurrents": {
		filePath: "/workspace/src/routes/abonnements-recurrents.tsx",
		children: void 0,
		preloads: ["/assets/abonnements-recurrents-BSLEW1uh.js", "/assets/public-DkN5cuGU.js"]
	},
	"/aide": {
		filePath: "/workspace/src/routes/aide.tsx",
		children: void 0,
		preloads: [
			"/assets/aide-CntroRtm.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/analytique": {
		filePath: "/workspace/src/routes/analytique.tsx",
		children: void 0,
		preloads: [
			"/assets/analytique-B8eL3TNJ.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/observe-wvyLEcq9.js"
		]
	},
	"/budget-personnel": {
		filePath: "/workspace/src/routes/budget-personnel.tsx",
		children: void 0,
		preloads: ["/assets/budget-personnel-Df4brHgA.js", "/assets/public-DkN5cuGU.js"]
	},
	"/business": {
		filePath: "/workspace/src/routes/business.tsx",
		children: void 0,
		preloads: [
			"/assets/business-BsUStqI0.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/observe-wvyLEcq9.js"
		]
	},
	"/compte": {
		filePath: "/workspace/src/routes/compte.tsx",
		children: void 0,
		preloads: [
			"/assets/compte-DzZFzouu.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/conditions": {
		filePath: "/workspace/src/routes/conditions.tsx",
		children: void 0,
		preloads: ["/assets/conditions-ud384LRR.js", "/assets/public-DkN5cuGU.js"]
	},
	"/confidentialite": {
		filePath: "/workspace/src/routes/confidentialite.tsx",
		children: void 0,
		preloads: ["/assets/confidentialite-7THLY_BP.js", "/assets/public-DkN5cuGU.js"]
	},
	"/configuration": {
		filePath: "/workspace/src/routes/configuration.tsx",
		children: void 0,
		preloads: ["/assets/configuration-DrVIjKyM.js", "/assets/gate-DTxZ_Vwo.js"]
	},
	"/connexion": {
		filePath: "/workspace/src/routes/connexion.tsx",
		children: void 0,
		preloads: ["/assets/connexion-Clk0yKyK.js", "/assets/gate-DTxZ_Vwo.js"]
	},
	"/controle": {
		filePath: "/workspace/src/routes/controle.tsx",
		children: void 0,
		preloads: [
			"/assets/controle-ChaHXq0S.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/dettes": {
		filePath: "/workspace/src/routes/dettes.tsx",
		children: void 0,
		preloads: [
			"/assets/dettes-KQlGOmpz.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/plan-DUIhn-Ot.js"
		]
	},
	"/epargne": {
		filePath: "/workspace/src/routes/epargne.tsx",
		children: void 0,
		preloads: [
			"/assets/epargne-DWrCX1UI.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/plan-DUIhn-Ot.js"
		]
	},
	"/historique": {
		filePath: "/workspace/src/routes/historique.tsx",
		children: void 0,
		preloads: [
			"/assets/historique-CmxXKSLw.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/money-5sD9TclY.js"
		]
	},
	"/inscription": {
		filePath: "/workspace/src/routes/inscription.tsx",
		children: void 0,
		preloads: ["/assets/inscription-qyIHHiOC.js", "/assets/gate-DTxZ_Vwo.js"]
	},
	"/parametres": {
		filePath: "/workspace/src/routes/parametres.tsx",
		children: void 0,
		preloads: [
			"/assets/parametres-DhzxgusV.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/parametres-pro": {
		filePath: "/workspace/src/routes/parametres-pro.tsx",
		children: void 0,
		preloads: [
			"/assets/parametres-pro-DUSKRPsi.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/patrimoine": {
		filePath: "/workspace/src/routes/patrimoine.tsx",
		children: void 0,
		preloads: [
			"/assets/patrimoine-a5toauZP.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/planner": {
		filePath: "/workspace/src/routes/planner.tsx",
		children: void 0,
		preloads: [
			"/assets/planner-DAGNdkVJ.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/plan-DUIhn-Ot.js"
		]
	},
	"/rapport": {
		filePath: "/workspace/src/routes/rapport.tsx",
		children: void 0,
		preloads: [
			"/assets/rapport-D4xqncKs.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/observe-wvyLEcq9.js"
		]
	},
	"/recurrences": {
		filePath: "/workspace/src/routes/recurrences.tsx",
		children: void 0,
		preloads: [
			"/assets/recurrences-D7zc521r.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/money-5sD9TclY.js"
		]
	},
	"/regles": {
		filePath: "/workspace/src/routes/regles.tsx",
		children: void 0,
		preloads: [
			"/assets/regles-CVE1Xps6.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/scanner": {
		filePath: "/workspace/src/routes/scanner.tsx",
		children: void 0,
		preloads: [
			"/assets/scanner-Bl88nmZd.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/securite": {
		filePath: "/workspace/src/routes/securite.tsx",
		children: void 0,
		preloads: [
			"/assets/securite-CdIkxUyO.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/system-FtGbFPdV.js"
		]
	},
	"/smart": {
		filePath: "/workspace/src/routes/smart.tsx",
		children: void 0,
		preloads: [
			"/assets/smart-aeZR9YjS.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/plan-DUIhn-Ot.js"
		]
	},
	"/suivi-depenses": {
		filePath: "/workspace/src/routes/suivi-depenses.tsx",
		children: void 0,
		preloads: ["/assets/suivi-depenses-BPehwuFV.js", "/assets/public-DkN5cuGU.js"]
	},
	"/transactions": {
		filePath: "/workspace/src/routes/transactions.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-D8_iN-kG.js",
			"/assets/shell-Cnc7h8eE.js",
			"/assets/money-5sD9TclY.js"
		]
	},
	"/tresorerie": {
		filePath: "/workspace/src/routes/tresorerie.tsx",
		children: void 0,
		preloads: ["/assets/tresorerie-zQsGSw0E.js", "/assets/public-DkN5cuGU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
