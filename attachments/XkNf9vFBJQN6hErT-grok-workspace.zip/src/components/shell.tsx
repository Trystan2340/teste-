import { Link, useRouterState } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  Bell,
  Briefcase,
  CalendarRange,
  ClipboardCheck,
  CreditCard,
  Gem,
  HelpCircle,
  History,
  Landmark,
  LayoutDashboard,
  LineChart,
  Menu,
  PiggyBank,
  Repeat,
  Scale,
  Search,
  Settings,
  Shield,
  Sparkles,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { HELP, type Mode } from "@/lib/freev/data";
import { useFreev } from "@/lib/freev/store";
import { Overlays } from "@/components/overlays";
import { cn } from "@/lib/utils";

const GROUPS = [
  {
    label: null as string | null,
    items: [
      { to: "/", label: "Tableau de bord", icon: LayoutDashboard },
      { to: "/analytique", label: "Analytique", icon: LineChart },
      { to: "/business", label: "Business", icon: Briefcase },
    ],
  },
  {
    label: "Opérations",
    items: [
      { to: "/transactions", label: "Transactions", icon: ArrowLeftRight },
      { to: "/recurrences", label: "Récurrences", icon: Repeat },
      { to: "/historique", label: "Historique", icon: History },
    ],
  },
  {
    label: "Planification",
    items: [
      { to: "/planner", label: "Planner", icon: CalendarRange },
      { to: "/smart", label: "Smart", icon: Sparkles },
      { to: "/epargne", label: "Épargne", icon: PiggyBank },
      { to: "/dettes", label: "Dettes", icon: Landmark },
    ],
  },
  {
    label: null,
    items: [{ to: "/parametres", label: "Paramètres", icon: Settings }],
  },
  {
    label: "Centre",
    items: [
      { to: "/controle", label: "Contrôle mensuel", icon: ClipboardCheck },
      { to: "/regles", label: "Règles", icon: Scale },
      { to: "/abonnements", label: "Abonnements", icon: CreditCard },
      { to: "/patrimoine", label: "Patrimoine", icon: Gem },
      { to: "/securite", label: "Sécurité", icon: Shield },
    ],
  },
];

const MODES: { id: Mode; label: string }[] = [
  { id: "perso", label: "Personnel" },
  { id: "pro", label: "Pro" },
  { id: "both", label: "Les deux" },
];

function isActive(path: string, to: string) {
  return to === "/" ? path === "/" : path === to;
}

function Rail({ onNavigate }: { onNavigate?: () => void }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const theme = useFreev((s) => s.theme);
  const setTheme = useFreev((s) => s.setTheme);
  const profile = useFreev((s) => s.profile);
  return (
    <div className="flex h-full flex-col bg-card">
      <div className="border-b border-rule px-5 py-5">
        <Link to="/" onClick={onNavigate} className="block">
          <span className="font-serif text-2xl tracking-tight">FREEV</span>
          <span className="mt-1 block text-xs uppercase tracking-widest text-mist">Livre de comptes</span>
        </Link>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4" aria-label="Navigation">
        {GROUPS.map((group) => (
          <div key={group.label ?? group.items[0].to} className="mb-4">
            {group.label ? (
              <p className="px-2 pb-2 text-xs uppercase tracking-widest text-mist">{group.label}</p>
            ) : null}
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const on = isActive(path, item.to);
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      onClick={onNavigate}
                      className={cn(
                        "flex items-center gap-3 border-l-2 px-2 py-2 text-sm",
                        on ? "border-copper bg-card-2 text-ink" : "border-transparent text-mist hover:text-ink",
                      )}
                    >
                      <Icon className="size-4 shrink-0" strokeWidth={1.5} aria-hidden />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
      <div className="space-y-3 border-t border-rule p-4">
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setTheme(theme === "paper" ? "ink" : "paper")}
            className="h-9 flex-1 border border-rule text-xs uppercase tracking-widest"
          >
            {theme === "paper" ? "Clair" : theme === "ink" ? "Sombre" : "Système"}
          </button>
          <Link
            to="/aide"
            onClick={onNavigate}
            className="inline-flex size-9 items-center justify-center border border-rule"
            aria-label="Aide"
          >
            <HelpCircle className="size-4" strokeWidth={1.5} />
          </Link>
        </div>
        <Link to="/compte" onClick={onNavigate} className="flex items-center gap-3">
          <span className="inline-flex size-9 items-center justify-center border border-copper font-serif text-copper">
            {profile.name.slice(0, 1)}
          </span>
          <span className="min-w-0">
            <span className="block truncate text-sm">{profile.name}</span>
            <span className="block truncate text-xs text-mist">{profile.email}</span>
          </span>
        </Link>
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const mode = useFreev((s) => s.mode);
  const setMode = useFreev((s) => s.setMode);
  const navOpen = useFreev((s) => s.navOpen);
  const setNav = useFreev((s) => s.setNav);
  const setSearch = useFreev((s) => s.setSearch);
  const setNotif = useFreev((s) => s.setNotif);
  const setUser = useFreev((s) => s.setUser);
  const notifOpen = useFreev((s) => s.notifOpen);
  const userOpen = useFreev((s) => s.userOpen);
  const notifs = useFreev((s) => s.notifs);
  const profile = useFreev((s) => s.profile);
  const unread = notifs.filter((n) => !n.read).length;
  const theme = useFreev((s) => s.theme);

  useEffect(() => {
    void useFreev.persist.rehydrate();
  }, []);

  useEffect(() => {
    const apply = () => {
      const choice = useFreev.getState().theme;
      const dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      document.documentElement.dataset.theme = choice === "system" ? (dark ? "ink" : "paper") : choice;
    };
    apply();
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    mq.addEventListener("change", apply);
    const unsub = useFreev.subscribe(apply);
    return () => {
      mq.removeEventListener("change", apply);
      unsub();
    };
  }, [theme]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "/" || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k")) {
        e.preventDefault();
        setSearch(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSearch]);

  const title =
    GROUPS.flatMap((g) => g.items).find((i) => isActive(path, i.to))?.label ?? "FREEV";

  return (
    <div className="flex h-dvh overflow-hidden bg-canvas text-ink">
      <aside className="hidden w-60 shrink-0 border-r border-rule lg:block">
        <Rail />
      </aside>
      {navOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button type="button" aria-label="Fermer le menu" className="veil absolute inset-0" onClick={() => setNav(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 border-r border-rule shadow-lift">
            <Rail onNavigate={() => setNav(false)} />
          </aside>
        </div>
      ) : null}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-rule px-3 md:px-5">
          <button type="button" className="inline-flex size-10 items-center justify-center lg:hidden" aria-label="Ouvrir le menu" onClick={() => setNav(true)}>
            <Menu className="size-5" strokeWidth={1.5} />
          </button>
          <p className="hidden min-w-0 truncate text-xs uppercase tracking-widest text-mist sm:block">{title}</p>
          <div className="ml-auto flex items-center gap-2 md:gap-4">
            <div className="hidden items-center gap-1 md:flex" role="tablist" aria-label="Périmètre">
              {MODES.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  role="tab"
                  aria-selected={mode === m.id}
                  onClick={() => setMode(m.id)}
                  className={cn(
                    "h-9 px-2 text-xs uppercase tracking-widest",
                    mode === m.id ? "border-b border-copper text-ink" : "text-mist hover:text-ink",
                  )}
                >
                  {m.label}
                </button>
              ))}
            </div>
            <label className="md:hidden">
              <span className="sr-only">Périmètre</span>
              <select
                value={mode}
                onChange={(e) => setMode(e.target.value as Mode)}
                className="h-9 border border-rule bg-transparent px-2 text-xs uppercase tracking-widest"
              >
                {MODES.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </select>
            </label>
            <button type="button" aria-label="Rechercher" className="inline-flex size-10 items-center justify-center" onClick={() => setSearch(true)}>
              <Search className="size-4" strokeWidth={1.5} />
            </button>
            <div className="relative">
              <button type="button" aria-label="Notifications" className="relative inline-flex size-10 items-center justify-center" onClick={() => setNotif(!notifOpen)}>
                <Bell className="size-4" strokeWidth={1.5} />
                {unread > 0 ? <span className="absolute top-2 right-2 size-1.5 bg-copper" /> : null}
              </button>
              {notifOpen ? <NotifPanel /> : null}
            </div>
            <div className="relative">
              <button
                type="button"
                aria-label="Compte"
                className="inline-flex size-9 items-center justify-center border border-rule font-serif"
                onClick={() => setUser(!userOpen)}
              >
                {profile.name.slice(0, 1)}
              </button>
              {userOpen ? <UserPanel /> : null}
            </div>
          </div>
        </header>
        <main className="min-h-0 flex-1 overflow-y-auto px-4 py-6 md:px-8 md:py-8">{children}</main>
      </div>
      <Overlays />
      <SearchOverlay />
    </div>
  );
}

function NotifPanel() {
  const notifs = useFreev((s) => s.notifs);
  const mark = useFreev((s) => s.markNotifs);
  const setNotif = useFreev((s) => s.setNotif);
  return (
    <div className="absolute right-0 z-30 mt-2 w-80 border border-rule bg-card p-4 shadow-lift">
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-widest text-mist">Notifications</p>
        <button type="button" className="text-xs uppercase tracking-widest text-copper" onClick={mark}>
          Tout lire
        </button>
      </div>
      <ul className="mt-3 divide-y divide-rule">
        {notifs.map((n) => (
          <li key={n.id}>
            <Link to={n.href} onClick={() => setNotif(false)} className="block py-3">
              <p className={cn("text-sm", !n.read && "text-ink")}>{n.title}</p>
              <p className="text-xs text-mist">{n.detail}</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-mist">{n.time}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function UserPanel() {
  const setUser = useFreev((s) => s.setUser);
  const profile = useFreev((s) => s.profile);
  const links = [
    { to: "/compte", label: "Mon compte" },
    { to: "/parametres", label: "Paramètres" },
    { to: "/securite", label: "Sécurité" },
    { to: "/connexion", label: "Déconnexion" },
  ];
  return (
    <div className="absolute right-0 z-30 mt-2 w-56 border border-rule bg-card p-2 shadow-lift">
      <p className="px-2 py-2 text-xs text-mist">{profile.email}</p>
      {links.map((l) => (
        <Link key={l.to} to={l.to} onClick={() => setUser(false)} className="block px-2 py-2 text-sm hover:bg-card-2">
          {l.label}
        </Link>
      ))}
    </div>
  );
}

function SearchOverlay() {
  const open = useFreev((s) => s.searchOpen);
  const setSearch = useFreev((s) => s.setSearch);
  const txs = useFreev((s) => s.txs);
  const [value, setValue] = useState("");
  useEffect(() => {
    if (!open) setValue("");
  }, [open]);
  if (!open) return null;
  const q = value.trim().toLowerCase();
  const pages = GROUPS.flatMap((g) => g.items).filter((i) => !q || i.label.toLowerCase().includes(q));
  const ops = txs.filter((t) => !q || `${t.label} ${t.category}`.toLowerCase().includes(q)).slice(0, 6);
  const help = HELP.filter((h) => !q || h.title.toLowerCase().includes(q));
  return (
    <div className="fixed inset-0 z-50">
      <button type="button" aria-label="Fermer la recherche" className="veil absolute inset-0" onClick={() => setSearch(false)} />
      <div role="dialog" aria-label="Recherche" className="relative mx-auto mt-16 w-full max-w-xl border border-rule bg-card p-5 shadow-lift">
        <div className="flex items-center gap-3 border-b border-rule">
          <Search className="size-4 text-mist" />
          <input
            autoFocus
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Page, opération, aide"
            className="h-12 w-full bg-transparent text-lg outline-none placeholder:text-mist"
          />
          <button type="button" aria-label="Fermer" onClick={() => setSearch(false)}>
            <X className="size-4" />
          </button>
        </div>
        <div className="mt-4 space-y-4">
          <Group title="Pages">
            {pages.map((p) => (
              <Link key={p.to} to={p.to} onClick={() => setSearch(false)} className="block py-2 text-sm">
                {p.label}
              </Link>
            ))}
          </Group>
          <Group title="Opérations">
            {ops.length === 0 ? <p className="text-sm text-mist">Aucune opération.</p> : null}
            {ops.map((t) => (
              <Link key={t.id} to="/transactions" onClick={() => setSearch(false)} className="block py-2 text-sm">
                {t.label}
              </Link>
            ))}
          </Group>
          <Group title="Aide">
            {help.map((h) => (
              <Link key={h.id} to="/aide" onClick={() => setSearch(false)} className="block py-2 text-sm">
                {h.title}
              </Link>
            ))}
          </Group>
        </div>
      </div>
    </div>
  );
}

function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-widest text-mist">{title}</p>
      <div className="mt-1">{children}</div>
    </div>
  );
}
