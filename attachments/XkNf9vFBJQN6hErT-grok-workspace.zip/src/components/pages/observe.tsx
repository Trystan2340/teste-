import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { FlowChart, SplitChart } from "@/components/charts";
import { Amount, Button, PageHead, Stat } from "@/components/ui";
import { flows, spentByCategory } from "@/lib/freev/calc";
import { HISTORY, SCHEDULE, SERIES, SNAP, TODAY, inScope } from "@/lib/freev/data";
import { useFreev } from "@/lib/freev/store";
import { dayLabel, money, pct } from "@/lib/utils";

export function Dashboard() {
  const mode = useFreev((s) => s.mode);
  const txs = useFreev((s) => s.txs);
  const accounts = useFreev((s) => s.accounts);
  const open = useFreev((s) => s.open);
  const flow = flows(txs, mode);
  const visible = accounts.filter((a) => inScope(a.scope, mode));
  const balance = visible.reduce((s, a) => s + a.balance, 0);
  const recent = [...txs].filter((t) => inScope(t.scope, mode)).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  const split = spentByCategory(txs, mode);
  const snap = SNAP[mode];

  return (
    <div className="space-y-8">
      <PageHead
        kicker="Novembre 2026 · N° 11"
        title="Tableau de bord"
        lede="Le mois en cours, les échéances encore devant, et ce qui a déjà bougé."
        actions={
          <>
            <Link to="/rapport" className="inline-flex h-11 items-center border border-rule px-4 text-xs uppercase tracking-widest">
              Rapport
            </Link>
            <Button variant="primary" onClick={() => open({ name: "tx" })}>
              Nouvelle opération
            </Button>
          </>
        }
      />

      <section className="grid border-b border-rule lg:grid-cols-12">
        <div className="py-6 lg:col-span-5 lg:pr-8">
          <p className="text-xs uppercase tracking-widest text-mist">Solde {mode === "pro" ? "pro" : mode === "perso" ? "personnel" : "global"}</p>
          <p className="mt-3 font-serif text-5xl tabular-nums md:text-6xl">{money(balance)}</p>
          <p className="mt-3 text-sm text-sage">{pct(snap.delta)} vs mois dernier</p>
        </div>
        <div className="grid grid-cols-1 border-t border-rule sm:grid-cols-3 lg:col-span-7 lg:border-t-0 lg:border-l">
          <Stat label="Entrées" value={money(flow.inn)} note="Mois en cours" tone="sage" />
          <Stat label="Sorties" value={money(flow.out)} note="Mois en cours" tone="clay" />
          <Stat label="Reste à vivre" value={money(flow.rest)} note="Entrées − sorties" />
        </div>
      </section>

      <section className="grid gap-10 lg:grid-cols-12">
        <div className="space-y-10 lg:col-span-7 lg:border-r lg:border-rule lg:pr-8">
          <div>
            <h2 className="font-serif text-2xl">Échéancier</h2>
            <ul className="mt-4 divide-y divide-rule border-y border-rule">
              {SCHEDULE.map((item) => {
                const passed = item.day < 19;
                return (
                  <li key={item.id} className="flex items-center justify-between gap-3 py-3">
                    <div>
                      <p className="text-sm">{item.label}</p>
                      <p className="text-xs uppercase tracking-widest text-mist">
                        {item.day} novembre · {passed ? "passé" : "à venir"}
                      </p>
                    </div>
                    <Amount value={item.amount} />
                  </li>
                );
              })}
            </ul>
          </div>
          <div>
            <div className="flex items-end justify-between">
              <h2 className="font-serif text-2xl">Activité récente</h2>
              <Link to="/transactions" className="text-xs uppercase tracking-widest text-copper">
                Journal
              </Link>
            </div>
            <ul className="mt-4 divide-y divide-rule">
              {recent.map((t) => (
                <li key={t.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm">{t.label}</p>
                    <p className="text-xs uppercase tracking-widest text-mist">
                      {dayLabel(t.date)} · {t.category}
                    </p>
                  </div>
                  <Amount value={t.kind === "transfer" ? t.amount : t.amount} kind={t.kind} />
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="space-y-10 lg:col-span-5">
          <div>
            <p className="text-xs uppercase tracking-widest text-mist">Santé du mois</p>
            <p className="mt-2 font-serif text-6xl tabular-nums">{snap.health}</p>
            <p className="mt-2 max-w-xs text-sm text-mist">Stable. Une charge d’énergie sort du rang, le reste suit le budget.</p>
          </div>
          <div>
            <div className="flex items-end justify-between">
              <h2 className="font-serif text-2xl">Comptes</h2>
              <div className="flex gap-3">
                <button type="button" className="text-xs uppercase tracking-widest text-copper" onClick={() => open({ name: "pick-account" })}>
                  Choisir
                </button>
                <button type="button" className="text-xs uppercase tracking-widest text-copper" onClick={() => open({ name: "accounts" })}>
                  Gérer
                </button>
              </div>
            </div>
            <ul className="mt-4 divide-y divide-rule border-y border-rule">
              {visible.map((a) => (
                <li key={a.id} className="flex items-center justify-between py-3">
                  <span>
                    <span className="block text-sm">{a.name}</span>
                    <span className="text-xs uppercase tracking-widest text-mist">{a.bank}</span>
                  </span>
                  <span className="tabular-nums">{money(a.balance)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="font-serif text-2xl">Répartition des sorties</h2>
            <SplitChart data={split} />
            <ul className="space-y-1">
              {split.slice(0, 5).map((c) => (
                <li key={c.name} className="flex justify-between text-sm">
                  <span>{c.name}</span>
                  <span className="tabular-nums text-mist">{money(c.value)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="border-l-2 border-copper pl-4">
            <p className="text-xs uppercase tracking-widest text-copper">Alertes</p>
            <p className="mt-2 text-sm">EDF a augmenté de 18 % par rapport à la moyenne.</p>
            <p className="mt-2 text-sm">2 abonnements se renouvellent cette semaine.</p>
            <Link to="/analytique" className="mt-3 inline-block text-xs uppercase tracking-widest text-copper">
              Voir l’analytique
            </Link>
          </div>
        </div>
      </section>
      <p className="text-xs text-mist">Date de référence {dayLabel(TODAY)}.</p>
    </div>
  );
}

export function Analytics() {
  const [span, setSpan] = useState(6);
  const mode = useFreev((s) => s.mode);
  const txs = useFreev((s) => s.txs);
  const flow = flows(txs, mode);
  const split = spentByCategory(txs, mode);
  const data = SERIES.slice(-span);
  const rate = flow.inn ? (flow.rest / flow.inn) * 100 : 0;

  return (
    <div className="space-y-8">
      <PageHead
        kicker="Analytique"
        title="Ce que le mois raconte"
        lede="Entrées, sorties, et les catégories qui pèsent — sur la période choisie."
        actions={
          <label className="text-xs uppercase tracking-widest text-mist">
            Période
            <select
              value={span}
              onChange={(e) => setSpan(Number(e.target.value))}
              className="ml-2 h-11 border border-rule bg-transparent px-2 text-ink"
            >
              <option value={3}>3 mois</option>
              <option value={6}>6 mois</option>
            </select>
          </label>
        }
      />
      <section className="grid border-y border-rule sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Entrées" value={money(flow.inn)} note={pct(6.4)} tone="sage" />
        <Stat label="Sorties" value={money(flow.out)} note={pct(-2.1)} tone="sage" />
        <Stat label="Épargne nette" value={money(flow.rest)} note="Novembre" />
        <Stat label="Taux d’épargne" value={`${rate.toFixed(1).replace(".", ",")} %`} note="Du mois" />
      </section>
      <section>
        <h2 className="font-serif text-2xl">Flux mensuel</h2>
        <div className="mt-4">
          <FlowChart data={data} />
        </div>
      </section>
      <section className="grid gap-8 lg:grid-cols-2">
        <div>
          <h2 className="font-serif text-2xl">Catégories</h2>
          <ul className="mt-4 divide-y divide-rule border-y border-rule">
            {split.map((c) => (
              <li key={c.name} className="flex items-center justify-between py-3 text-sm">
                <span>{c.name}</span>
                <span className="tabular-nums">{money(c.value)}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-serif text-2xl">Novembre contre octobre</h2>
          <table className="mt-4 w-full text-sm">
            <thead className="text-left text-xs uppercase tracking-widest text-mist">
              <tr>
                <th className="py-2 font-medium"> </th>
                <th className="py-2 font-medium">Nov.</th>
                <th className="py-2 font-medium">Oct.</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-rule">
                <td className="py-3">Entrées</td>
                <td className="tabular-nums">{money(HISTORY[0].inn)}</td>
                <td className="tabular-nums text-mist">{money(HISTORY[1].inn)}</td>
              </tr>
              <tr className="border-t border-rule">
                <td className="py-3">Sorties</td>
                <td className="tabular-nums">{money(HISTORY[0].out)}</td>
                <td className="tabular-nums text-mist">{money(HISTORY[1].out)}</td>
              </tr>
              <tr className="border-t border-rule">
                <td className="py-3">Net</td>
                <td className="tabular-nums text-sage">{money(HISTORY[0].inn - HISTORY[0].out)}</td>
                <td className="tabular-nums text-mist">{money(HISTORY[1].inn - HISTORY[1].out)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

export function Business() {
  const invoices = useFreev((s) => s.invoices);
  const accounts = useFreev((s) => s.accounts);
  const open = useFreev((s) => s.open);
  const mark = useFreev((s) => s.markInvoice);
  const pro = accounts.find((a) => a.id === "pro");
  const waiting = invoices.filter((i) => i.status !== "payée");

  return (
    <div className="space-y-8">
      <PageHead
        kicker="Activité professionnelle"
        title="Business"
        lede="Chiffre facturé, charges, et ce que les clients vous doivent encore."
        actions={
          <Button variant="primary" onClick={() => open({ name: "invoice" })}>
            Nouvelle facture
          </Button>
        }
      />
      <section className="grid border-y border-rule sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="CA du mois" value={money(8640)} note="Facturé" />
        <Stat label="Charges" value={money(3120)} note="Estimées" tone="clay" />
        <Stat label="Résultat" value={money(5520)} note="Avant impôt" tone="sage" />
        <Stat label="Trésorerie" value={money(12480)} note={pro ? `dont Qonto ${money(pro.balance)}` : ""} />
      </section>
      <section className="grid gap-10 lg:grid-cols-2">
        <div>
          <h2 className="font-serif text-2xl">Clients</h2>
          <ul className="mt-4 divide-y divide-rule border-y border-rule">
            {[
              ["Atelier Nord", "AN", "Payée · 2 400 €"],
              ["Studio Lina", "SL", waiting.some((i) => i.client === "Studio Lina") ? "En attente · 1 800 €" : "Payée · 1 800 €"],
              ["Maison Brume", "MB", "Payée · 960 €"],
            ].map(([name, mark, last]) => (
              <li key={name} className="flex items-center gap-3 py-3">
                <span className="inline-flex size-10 items-center justify-center border border-rule font-serif text-sm">{mark}</span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm">{name}</span>
                  <span className="text-xs text-mist">{last}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-serif text-2xl">Factures</h2>
          <ul className="mt-4 divide-y divide-rule border-y border-rule">
            {invoices.map((inv) => (
              <li key={inv.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <div>
                  <p className="text-sm">
                    {inv.number} · {inv.client}
                  </p>
                  <p className="text-xs uppercase tracking-widest text-mist">
                    {dayLabel(inv.date)} · {inv.status}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="tabular-nums">{money(inv.amount)}</span>
                  {inv.status !== "payée" ? (
                    <>
                      <Button
                        size="sm"
                        onClick={() => {
                          toast(useFreev.getState().remind(inv.id));
                        }}
                      >
                        Relancer
                      </Button>
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => {
                          mark(inv.id);
                          toast("Facture marquée payée");
                        }}
                      >
                        Payée
                      </Button>
                    </>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}

export function Report() {
  const mode = useFreev((s) => s.mode);
  const txs = useFreev((s) => s.txs);
  const flow = flows(txs, mode);
  const split = spentByCategory(txs, mode);
  return (
    <div className="space-y-8">
      <PageHead
        kicker="Rapport mensuel"
        title="Novembre, en une page"
        lede="Le même récit que le tableau de bord, mis en forme pour être relu ou transmis."
        actions={
          <Button
            variant="primary"
            onClick={() => {
              const blob = new Blob(
                [JSON.stringify({ mois: "2026-11", entrees: flow.inn, sorties: flow.out, categories: split }, null, 2)],
                { type: "application/json" },
              );
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = "freev-novembre-2026.json";
              a.click();
              URL.revokeObjectURL(url);
              toast("Rapport exporté");
            }}
          >
            Exporter
          </Button>
        }
      />
      <article className="border border-rule p-6 md:p-10">
        <p className="text-xs uppercase tracking-widest text-copper">FREEV · Camille Morel</p>
        <h2 className="mt-3 font-serif text-4xl">Livre de novembre</h2>
        <p className="mt-4 max-w-2xl text-sm text-mist">
          Les entrées du mois s’établissent à {money(flow.inn)}, les sorties à {money(flow.out)}. Le reste à vivre est de {money(flow.rest)}. La santé du mois reste à {SNAP[mode].health}.
        </p>
        <dl className="mt-8 grid gap-4 sm:grid-cols-3">
          <div>
            <dt className="text-xs uppercase tracking-widest text-mist">Entrées</dt>
            <dd className="font-serif text-3xl">{money(flow.inn)}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-widest text-mist">Sorties</dt>
            <dd className="font-serif text-3xl">{money(flow.out)}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-widest text-mist">Net</dt>
            <dd className="font-serif text-3xl">{money(flow.rest)}</dd>
          </div>
        </dl>
        <h3 className="mt-10 font-serif text-2xl">Sorties par poste</h3>
        <ul className="mt-3 divide-y divide-rule">
          {split.map((c) => (
            <li key={c.name} className="flex justify-between py-2 text-sm">
              <span>{c.name}</span>
              <span className="tabular-nums">{money(c.value)}</span>
            </li>
          ))}
        </ul>
      </article>
    </div>
  );
}
