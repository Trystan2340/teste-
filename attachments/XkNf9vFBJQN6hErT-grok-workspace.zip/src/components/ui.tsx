import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import type { TxKind } from "@/lib/freev/data";
import { cn, money, signed } from "@/lib/utils";

const buttonStyles = cva(
  "inline-flex items-center justify-center gap-2 border text-xs font-medium uppercase tracking-widest transition-colors disabled:pointer-events-none disabled:opacity-40",
  {
    variants: {
      variant: {
        primary: "border-copper bg-copper text-copper-ink hover:border-ink hover:bg-ink hover:text-canvas",
        ghost: "border-rule bg-transparent text-ink hover:border-ink",
        quiet: "border-transparent bg-transparent px-0 text-mist hover:text-ink",
      },
      size: {
        md: "h-11 px-4",
        sm: "h-9 px-3",
      },
    },
    defaultVariants: { variant: "ghost", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonStyles>) {
  return <button className={cn(buttonStyles({ variant, size }), className)} {...props} />;
}

export function Field({
  label,
  hint,
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="text-xs uppercase tracking-widest text-mist">{label}</span>
      <input
        className="mt-1 w-full border-0 border-b border-rule bg-transparent py-2 text-sm text-ink outline-none placeholder:text-mist focus:border-copper"
        {...props}
      />
      {hint ? <span className="mt-1 block text-xs text-clay">{hint}</span> : null}
    </label>
  );
}

export function Area({
  label,
  className,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="text-xs uppercase tracking-widest text-mist">{label}</span>
      <textarea
        className="mt-1 w-full resize-none border-0 border-b border-rule bg-transparent py-2 text-sm text-ink outline-none focus:border-copper"
        rows={3}
        {...props}
      />
    </label>
  );
}

export function Select({
  label,
  children,
  className,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement> & { label: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="text-xs uppercase tracking-widest text-mist">{label}</span>
      <select
        className="mt-1 w-full border-0 border-b border-rule bg-transparent py-2 text-sm text-ink outline-none focus:border-copper"
        {...props}
      >
        {children}
      </select>
    </label>
  );
}

export function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cn("relative h-6 w-11 border", on ? "border-copper bg-copper" : "border-rule bg-transparent")}
    >
      <span
        className={cn(
          "absolute top-0.5 size-4 transition-transform",
          on ? "translate-x-6 bg-copper-ink" : "translate-x-0.5 bg-mist",
        )}
      />
    </button>
  );
}

export function PageHead({
  kicker,
  title,
  lede,
  actions,
}: {
  kicker: string;
  title: string;
  lede?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="flex flex-col gap-4 border-b border-rule pb-6 md:flex-row md:items-end md:justify-between">
      <div className="min-w-0">
        <p className="text-xs uppercase tracking-widest text-copper">{kicker}</p>
        <h1 className="mt-2 font-serif text-4xl leading-none text-ink md:text-5xl">{title}</h1>
        {lede ? <p className="mt-3 max-w-xl text-sm text-mist">{lede}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}

export function Stat({
  label,
  value,
  note,
  tone,
}: {
  label: string;
  value: string;
  note?: string;
  tone?: "sage" | "clay" | "mist";
}) {
  return (
    <div className="px-4 py-5 first:pl-0 last:pr-0">
      <p className="text-xs uppercase tracking-widest text-mist">{label}</p>
      <p className="mt-2 font-serif text-3xl tabular-nums text-ink">{value}</p>
      {note ? (
        <p className={cn("mt-1 text-sm", tone === "sage" && "text-sage", tone === "clay" && "text-clay", (!tone || tone === "mist") && "text-mist")}>
          {note}
        </p>
      ) : null}
    </div>
  );
}

export function Amount({ value, kind }: { value: number; kind?: TxKind }) {
  if (kind === "transfer") {
    return <span className="tabular-nums text-mist">{money(value)}</span>;
  }
  return (
    <span className={cn("tabular-nums", value > 0 && "text-sage", value < 0 && "text-clay")}>{signed(value)}</span>
  );
}

export function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="border border-dashed border-rule px-4 py-10 text-center">
      <p className="font-serif text-2xl">{title}</p>
      <p className="mt-2 text-sm text-mist">{body}</p>
    </div>
  );
}
